# Integration Testing Guide

## Testing Slack Integration

### Setup
1. Start the backend: `cd server && npm start`
2. Note your org ID (check the login response or database)

### Test 1: Simulate incoming Slack message (creates new ticket)
```bash
curl -X POST http://localhost:3001/api/webhooks/slack/org-1/test \
  -H "Content-Type: application/json" \
  -d '{
    "text": "URGENT: Production database is down! Getting 500 errors on all requests.",
    "user": "U123ABC",
    "channel": "C456DEF"
  }'
```

Expected result:
- New ticket created in org-1
- Channel = "slack"
- Priority auto-detected as "critical" (contains "urgent")
- Check response for `ticketId`

### Test 2: Reply to Slack thread (adds message to existing ticket)
First, get a ticket ID from Test 1, then:
```bash
# The system automatically maps the thread - just send another message
# with the same user/channel combo
curl -X POST http://localhost:3001/api/webhooks/slack/org-1/test \
  -H "Content-Type: application/json" \
  -d '{
    "text": "Update: We rolled back the deploy and service is restored.",
    "user": "U123ABC",
    "channel": "C456DEF"
  }'
```

### Test 3: Agent replies via UI
1. Log into frontend as admin@acme.com
2. Open the ticket created in Test 1
3. Type a reply and hit Send
4. Check server console for `[SLACK] Sending to...` log

---

## Testing Email Integration

### Test 1: Simulate incoming email (creates new ticket)
```bash
curl -X POST http://localhost:3001/api/webhooks/email/org-1/test \
  -H "Content-Type: application/json" \
  -d '{
    "from": "Jane Customer <jane@bigcorp.com>",
    "subject": "Critical: Payment processing failing",
    "text": "Hi Support Team,\n\nOur payment gateway has been returning errors for the past hour. Customers cannot complete purchases. This is extremely urgent as we are losing revenue.\n\nError code: GATEWAY_TIMEOUT\n\nPlease help ASAP!\n\nThanks,\nJane"
  }'
```

Expected result:
- New ticket created
- Channel = "email"
- Priority = "critical" (detected from keywords)
- Customer name = "Jane Customer"
- Auto-reply sent (check console logs)

### Test 2: Email reply to existing ticket
```bash
curl -X POST http://localhost:3001/api/webhooks/email/org-1/test \
  -H "Content-Type: application/json" \
  -d '{
    "from": "Jane Customer <jane@bigcorp.com>",
    "subject": "Re: Critical: Payment processing failing",
    "text": "Thanks for the quick response! I can confirm the issue is now resolved on our end.",
    "headers": {
      "In-Reply-To": "<TKT-1090@supportos.local>",
      "Message-ID": "<reply-123@bigcorp.com>"
    }
  }'
```

Note: Replace `TKT-1090` with the actual ticket ID from Test 1.

### Test 3: Email with attachments
```bash
curl -X POST http://localhost:3001/api/webhooks/email/org-1/test \
  -H "Content-Type: application/json" \
  -d '{
    "from": "Bob Developer <bob@startup.io>",
    "subject": "API integration help needed",
    "text": "Hi, I am trying to integrate your API but getting authentication errors. See attached screenshot of the error.",
    "attachments": [
      {
        "filename": "error-screenshot.png",
        "type": "image/png",
        "size": 45230,
        "content": "base64-encoded-data-here"
      }
    ]
  }'
```

---

## Testing Full Workflow

### Scenario: Customer contacts via Slack, agent responds

1. **Customer sends Slack message:**
```bash
curl -X POST http://localhost:3001/api/webhooks/slack/org-1/test \
  -H "Content-Type: application/json" \
  -d '{"text": "Hey support, our dashboard is loading very slowly today. Is there an issue?"}'
```

2. **Log into frontend** as admin@acme.com

3. **Find the new ticket** in Inbox (should show channel badge "Slack")

4. **Click the ticket** to open floating pane

5. **See the original Slack message** in Conversation tab

6. **Assign to yourself** using Assign button

7. **Reply to customer:**
   - Type: "Thanks for reaching out! We are investigating the performance issue. Will update you in 15 minutes."
   - Click Send
   - Check server console - should see `[SLACK] Sending to...`

8. **Customer sends follow-up:**
```bash
curl -X POST http://localhost:3001/api/webhooks/slack/org-1/test \
  -H "Content-Type: application/json" \
  -d '{"text": "Okay thanks! Really appreciate the quick response."}'
```

9. **Refresh ticket** in UI - new message should appear

10. **Resolve the ticket:**
    - Type: "Issue has been resolved. We optimized some database queries. Let us know if you notice any other slowness."
    - Click Send
    - Change status to "Resolved"

---

## Integration Configuration

### Slack Setup (Production)
1. Create Slack App at api.slack.com/apps
2. Add Bot Token Scopes:
   - `chat:write` - Send messages
   - `channels:read` - List channels
   - `im:read` - Read DMs
   - `users:read` - Get user info
3. Enable Event Subscriptions:
   - Request URL: `https://your-domain.com/api/webhooks/slack/YOUR_ORG_ID`
   - Subscribe to bot events:
     - `message.channels`
     - `message.im`
     - `app_mention`
4. Install app to workspace
5. Copy Bot User OAuth Token (xoxb-...)
6. In SupportOS Settings > Integrations > Slack:
   - Paste Bot Token
   - Enter workspace name
   - Enter alert channel (e.g., #support-alerts)
   - Set notification priority filter
   - Enable auto-reply
   - Click Connect

### Email Setup (Production)

#### Option 1: SendGrid Inbound Parse
1. Go to SendGrid > Settings > Inbound Parse
2. Add destination: `support@yourdomain.com`
3. Set webhook URL: `https://your-domain.com/api/webhooks/email/YOUR_ORG_ID`
4. Configure DNS MX records for your domain
5. In SupportOS:
   - Settings > Integrations > Email
   - Provider: SendGrid
   - From Address: support@yourdomain.com
   - From Name: Your Support Team
   - Enable auto-reply
   - Click Connect

#### Option 2: Mailgun
1. Create Mailgun account, verify domain
2. Go to Receiving > Routes
3. Create route:
   - Filter: `match_recipient("support@yourdomain.com")`
   - Action: forward to `https://your-domain.com/api/webhooks/email/YOUR_ORG_ID`
4. In SupportOS, configure with Mailgun SMTP credentials

#### Option 3: Custom SMTP
1. Settings > Integrations > Email
2. Provider: Custom SMTP
3. Enter SMTP host, port, credentials
4. Set webhook URL in your email provider
5. Configure forwarding rules

---

## Monitoring & Debugging

### Check logs
```bash
# Server logs show all incoming webhooks
tail -f server.log

# Look for:
[SLACK] Sending to...
[EMAIL] Sending to...
[SLACK WEBHOOK ERROR]
[EMAIL WEBHOOK ERROR]
```

### Verify webhook delivery
```bash
# Test webhook endpoint is accessible
curl http://localhost:3001/api/health

# Test Slack webhook (should get URL verification challenge)
curl -X POST http://localhost:3001/api/webhooks/slack/org-1 \
  -H "Content-Type: application/json" \
  -d '{"type": "url_verification", "challenge": "test123"}'

# Should respond with: {"challenge": "test123"}
```

### Common issues
1. **Webhook not receiving events:**
   - Check firewall/ngrok if testing locally
   - Verify webhook URL is correct in Slack/Email settings
   - Check SSL certificate is valid

2. **Messages not creating tickets:**
   - Check org ID in webhook URL matches database
   - Verify integration is marked as "connected" in db.integrations
   - Check server logs for errors

3. **Agent replies not sending:**
   - Verify ticket has slackThreadTs/emailMessageId
   - Check bot token permissions
   - Look for [SEND REPLY ERROR] in logs

---

## Advanced Testing

### Load Testing
```bash
# Create 100 tickets via Slack
for i in {1..100}; do
  curl -X POST http://localhost:3001/api/webhooks/slack/org-1/test \
    -H "Content-Type: application/json" \
    -d "{\"text\": \"Test ticket #$i\"}"
  sleep 0.1
done
```

### Test Auto-Priority Detection
```bash
# Should create "critical" ticket
curl -X POST http://localhost:3001/api/webhooks/email/org-1/test \
  -d '{"subject": "URGENT production down", "text": "critical outage"}'

# Should create "high" ticket  
curl -X POST http://localhost:3001/api/webhooks/email/org-1/test \
  -d '{"subject": "Important issue", "text": "need help asap"}'

# Should create "medium" ticket
curl -X POST http://localhost:3001/api/webhooks/email/org-1/test \
  -d '{"subject": "Question about feature", "text": "how does this work?"}'
```

### Test Threading
```bash
# Create initial ticket
RESULT=$(curl -s -X POST http://localhost:3001/api/webhooks/slack/org-1/test \
  -H "Content-Type: application/json" \
  -d '{"text": "Initial message", "user": "U111"}')

TICKET_ID=$(echo $RESULT | jq -r '.result.ticketId')
echo "Created ticket: $TICKET_ID"

# Send 3 follow-up messages (should all append to same ticket)
for i in {1..3}; do
  curl -X POST http://localhost:3001/api/webhooks/slack/org-1/test \
    -H "Content-Type: application/json" \
    -d "{\"text\": \"Follow-up message $i\", \"user\": \"U111\"}"
done

# Verify ticket has 4 messages
curl http://localhost:3001/api/tickets/$TICKET_ID/messages \
  -H "Authorization: Bearer YOUR_TOKEN"
```
