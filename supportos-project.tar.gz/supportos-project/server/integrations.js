/**
 * SupportOS Integration Handlers
 * Slack & Email channel integrations with webhook handlers
 */

const crypto = require("crypto");

// ─── Slack Integration ────────────────────────────────────────────────────────

/**
 * Slack Configuration:
 * - Bot OAuth Token (xoxb-...)
 * - Signing Secret (for webhook verification)
 * - Channel IDs for ticket creation
 * - Thread mapping (Slack thread TS <-> Ticket ID)
 */

class SlackIntegration {
  constructor(db) {
    this.db = db;
    this.threadMap = {}; // { slackThreadTs: ticketId }
  }

  /**
   * Verify Slack webhook signature
   * https://api.slack.com/authentication/verifying-requests-from-slack
   */
  verifySlackSignature(req) {
    const signature = req.headers["x-slack-signature"];
    const timestamp = req.headers["x-slack-request-timestamp"];
    const body = JSON.stringify(req.body);

    // Prevent replay attacks (timestamp within 5 minutes)
    if (Math.abs(Date.now() / 1000 - timestamp) > 300) return false;

    const sigBasestring = `v0:${timestamp}:${body}`;
    const mySignature = "v0=" + crypto
      .createHmac("sha256", process.env.SLACK_SIGNING_SECRET || "dev-secret")
      .update(sigBasestring)
      .digest("hex");

    return crypto.timingSafeEqual(Buffer.from(signature), Buffer.from(mySignature));
  }

  /**
   * Handle incoming Slack webhook events
   */
  async handleWebhook(payload, orgId) {
    const { type, event, challenge } = payload;

    // URL verification challenge
    if (type === "url_verification") return { challenge };

    // Event callback
    if (type === "event_callback" && event) {
      switch (event.type) {
        case "message":
          return await this.handleMessage(event, orgId);
        case "app_mention":
          return await this.handleMention(event, orgId);
        default:
          return { ok: true };
      }
    }

    return { ok: true };
  }

  /**
   * Handle incoming Slack message
   * - DMs create new tickets
   * - Thread replies append to existing tickets
   * - Channel mentions create tickets
   */
  async handleMessage(event, orgId) {
    const { user, text, channel, thread_ts, ts, bot_id } = event;

    // Ignore bot messages
    if (bot_id) return { ok: true };

    // Check if this is a threaded reply to an existing ticket
    const threadKey = thread_ts || ts;
    const existingTicketId = this.threadMap[threadKey];

    if (existingTicketId) {
      // Append message to existing ticket
      const ticket = this.db.tickets.find(t => t.id === existingTicketId && t.orgId === orgId);
      if (ticket) {
        const message = {
          id: require("uuid").v4(),
          ticketId: ticket.id,
          type: "customer",
          authorName: await this.getSlackUserName(user, orgId),
          authorEmail: `${user}@slack`,
          body: text,
          attachments: [],
          createdAt: new Date().toISOString(),
        };
        if (!this.db.messages[ticket.id]) this.db.messages[ticket.id] = [];
        this.db.messages[ticket.id].push(message);
        ticket.updatedAt = new Date().toISOString();
        ticket.unread = true;

        // Send Slack notification to assigned agent
        if (ticket.assigneeId) {
          await this.sendNotification(orgId, ticket, `New message from ${message.authorName}`);
        }
      }
      return { ok: true };
    }

    // Create new ticket from DM or channel message
    const userName = await this.getSlackUserName(user, orgId);
    const ticket = {
      id: this.generateTicketId(orgId),
      orgId,
      title: text.substring(0, 100) + (text.length > 100 ? "..." : ""),
      channel: "slack",
      priority: "medium",
      status: "open",
      assigneeId: null,
      tags: ["slack", "auto-created"],
      customer: userName,
      customerEmail: `${user}@slack`,
      sla: 240,
      slaPct: 0,
      jira: null,
      linear: null,
      unread: true,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      customFields: {
        productArea: "Customer Support",
        severity: "P3",
        tier: "",
        contractValue: "",
      },
      slackThreadTs: threadKey,
      slackChannel: channel,
      slackUser: user,
    };

    this.db.tickets.push(ticket);
    this.db.messages[ticket.id] = [
      {
        id: require("uuid").v4(),
        ticketId: ticket.id,
        type: "customer",
        authorName: userName,
        authorEmail: `${user}@slack`,
        body: text,
        attachments: [],
        createdAt: new Date().toISOString(),
      },
    ];
    this.db.attachments[ticket.id] = [];

    // Map thread to ticket
    this.threadMap[threadKey] = ticket.id;

    // Auto-reply if enabled
    const integration = this.db.integrations[orgId]?.slack;
    if (integration?.config?.autoReply) {
      await this.sendMessage(orgId, channel, `Thanks for reaching out! We've created ticket ${ticket.id} and will get back to you soon.`, threadKey);
    }

    // Notify channel
    await this.sendNotification(orgId, ticket, `New ticket from Slack: ${ticket.id}`);

    return { ok: true, ticketId: ticket.id };
  }

  /**
   * Handle Slack @mention
   */
  async handleMention(event, orgId) {
    // Treat mentions as regular messages
    return await this.handleMessage(event, orgId);
  }

  /**
   * Send message to Slack
   */
  async sendMessage(orgId, channel, text, threadTs = null) {
    const integration = this.db.integrations[orgId]?.slack;
    if (!integration?.connected) {
      throw new Error("Slack not connected");
    }

    const botToken = integration.config.botToken;

    // In production, make actual Slack API call
    // const response = await fetch("https://slack.com/api/chat.postMessage", {
    //   method: "POST",
    //   headers: {
    //     "Authorization": `Bearer ${botToken}`,
    //     "Content-Type": "application/json",
    //   },
    //   body: JSON.stringify({
    //     channel,
    //     text,
    //     thread_ts: threadTs,
    //   }),
    // });

    // Mock response for demo
    console.log(`[SLACK] Sending to ${channel} (thread: ${threadTs}): ${text}`);
    return { ok: true, ts: Date.now().toString() };
  }

  /**
   * Send notification to alert channel
   */
  async sendNotification(orgId, ticket, message) {
    const integration = this.db.integrations[orgId]?.slack;
    if (!integration?.connected || !integration.config.channel) return;

    const notifyOn = (integration.config.notifyOn || "critical,high").split(",");
    if (!notifyOn.includes(ticket.priority)) return;

    const blocks = [
      {
        type: "section",
        text: {
          type: "mrkdwn",
          text: `*${message}*\n${ticket.title}`,
        },
      },
      {
        type: "section",
        fields: [
          { type: "mrkdwn", text: `*Ticket:*\n${ticket.id}` },
          { type: "mrkdwn", text: `*Priority:*\n${ticket.priority}` },
          { type: "mrkdwn", text: `*Status:*\n${ticket.status}` },
          { type: "mrkdwn", text: `*Customer:*\n${ticket.customer}` },
        ],
      },
      {
        type: "actions",
        elements: [
          {
            type: "button",
            text: { type: "plain_text", text: "View Ticket" },
            url: `http://localhost:5173/ticket/${ticket.id}`,
          },
        ],
      },
    ];

    // Mock send
    console.log(`[SLACK] Alert to ${integration.config.channel}:`, JSON.stringify(blocks, null, 2));
    return { ok: true };
  }

  /**
   * Get Slack user's display name
   */
  async getSlackUserName(userId, orgId) {
    const integration = this.db.integrations[orgId]?.slack;
    if (!integration?.connected) return `User ${userId}`;

    // In production, fetch from Slack API
    // const response = await fetch(`https://slack.com/api/users.info?user=${userId}`, {
    //   headers: { "Authorization": `Bearer ${integration.config.botToken}` },
    // });
    // const data = await response.json();
    // return data.user?.real_name || data.user?.name || userId;

    // Mock name
    return `Slack User ${userId.substring(0, 8)}`;
  }

  /**
   * Send agent reply back to Slack
   */
  async sendReply(ticket, message) {
    if (!ticket.slackThreadTs || !ticket.slackChannel) {
      throw new Error("Ticket not from Slack");
    }

    const text = `*${message.authorName}* (Support Agent):\n${message.body}`;
    return await this.sendMessage(ticket.orgId, ticket.slackChannel, text, ticket.slackThreadTs);
  }

  generateTicketId(orgId) {
    const tickets = this.db.tickets.filter(t => t.orgId === orgId);
    const nums = tickets.map(t => parseInt(t.id.split("-")[1]) || 0);
    return `TKT-${Math.max(0, ...nums) + 1}`;
  }
}

// ─── Email Integration ────────────────────────────────────────────────────────

/**
 * Email Configuration:
 * - Incoming email webhook (SendGrid, Mailgun, Postmark, etc.)
 * - SMTP settings for outgoing emails
 * - Email parsing and threading
 */

class EmailIntegration {
  constructor(db) {
    this.db = db;
    this.threadMap = {}; // { messageId: ticketId }
  }

  /**
   * Handle incoming email webhook (SendGrid Inbound Parse format)
   * https://docs.sendgrid.com/for-developers/parsing-email/setting-up-the-inbound-parse-webhook
   */
  async handleIncomingEmail(payload, orgId) {
    const {
      from,
      subject,
      text,
      html,
      to,
      headers,
      attachments = [],
    } = this.parseEmailPayload(payload);

    // Check if this is a reply to an existing ticket
    const inReplyTo = headers["In-Reply-To"] || headers["References"];
    const existingTicketId = this.extractTicketIdFromHeaders(inReplyTo);

    if (existingTicketId) {
      // Append reply to existing ticket
      const ticket = this.db.tickets.find(t => t.id === existingTicketId && t.orgId === orgId);
      if (ticket) {
        const message = {
          id: require("uuid").v4(),
          ticketId: ticket.id,
          type: "customer",
          authorName: this.parseFromName(from),
          authorEmail: this.parseFromEmail(from),
          body: text || this.stripHtml(html),
          attachments: [],
          createdAt: new Date().toISOString(),
        };
        if (!this.db.messages[ticket.id]) this.db.messages[ticket.id] = [];
        this.db.messages[ticket.id].push(message);
        ticket.updatedAt = new Date().toISOString();
        ticket.unread = true;

        // Handle attachments
        if (attachments.length > 0) {
          await this.processAttachments(ticket.id, attachments);
        }

        // Notify assigned agent
        if (ticket.assigneeId) {
          await this.sendInternalNotification(orgId, ticket, `New reply from ${message.authorName}`);
        }

        return { ok: true, ticketId: ticket.id };
      }
    }

    // Create new ticket from email
    const ticket = {
      id: this.generateTicketId(orgId),
      orgId,
      title: subject || "(No subject)",
      channel: "email",
      priority: this.detectPriorityFromEmail(text, subject),
      status: "open",
      assigneeId: null,
      tags: ["email", "auto-created"],
      customer: this.parseFromName(from),
      customerEmail: this.parseFromEmail(from),
      sla: 240,
      slaPct: 0,
      jira: null,
      linear: null,
      unread: true,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      customFields: {
        productArea: "Customer Support",
        severity: "P3",
        tier: "",
        contractValue: "",
      },
      emailMessageId: headers["Message-ID"],
      emailReplyTo: from,
    };

    this.db.tickets.push(ticket);
    this.db.messages[ticket.id] = [
      {
        id: require("uuid").v4(),
        ticketId: ticket.id,
        type: "customer",
        authorName: this.parseFromName(from),
        authorEmail: this.parseFromEmail(from),
        body: text || this.stripHtml(html),
        attachments: [],
        createdAt: new Date().toISOString(),
      },
    ];
    this.db.attachments[ticket.id] = [];

    // Process attachments
    if (attachments.length > 0) {
      await this.processAttachments(ticket.id, attachments);
    }

    // Map message ID to ticket
    if (headers["Message-ID"]) {
      this.threadMap[headers["Message-ID"]] = ticket.id;
    }

    // Auto-reply if enabled
    const integration = this.db.integrations[orgId]?.email;
    if (integration?.config?.autoReply) {
      await this.sendAutoReply(ticket);
    }

    return { ok: true, ticketId: ticket.id };
  }

  /**
   * Parse email payload (supports SendGrid, Mailgun, Postmark formats)
   */
  parseEmailPayload(payload) {
    // SendGrid format
    if (payload.from && payload.subject && payload.text) {
      return {
        from: payload.from,
        subject: payload.subject,
        text: payload.text,
        html: payload.html,
        to: payload.to,
        headers: payload.headers || {},
        attachments: payload.attachments || [],
      };
    }

    // Mailgun format
    if (payload.sender && payload.subject) {
      return {
        from: payload.sender,
        subject: payload.subject,
        text: payload["body-plain"],
        html: payload["body-html"],
        to: payload.recipient,
        headers: this.parseMailgunHeaders(payload),
        attachments: payload.attachments || [],
      };
    }

    // Generic format
    return {
      from: payload.from || payload.sender || "",
      subject: payload.subject || "",
      text: payload.text || payload.body || "",
      html: payload.html || "",
      to: payload.to || payload.recipient || "",
      headers: payload.headers || {},
      attachments: payload.attachments || [],
    };
  }

  parseMailgunHeaders(payload) {
    const headers = {};
    Object.keys(payload).forEach(key => {
      if (key.startsWith("h:") || key.startsWith("H:")) {
        const headerName = key.substring(2);
        headers[headerName] = payload[key];
      }
    });
    return headers;
  }

  /**
   * Extract ticket ID from email headers
   */
  extractTicketIdFromHeaders(headerValue) {
    if (!headerValue) return null;
    const match = headerValue.match(/TKT-\d+/);
    return match ? match[0] : null;
  }

  /**
   * Parse sender name from "Name <email@domain.com>" format
   */
  parseFromName(from) {
    const match = from.match(/^(.+?)\s*<.+>$/);
    return match ? match[1].trim().replace(/"/g, "") : from.split("@")[0];
  }

  parseFromEmail(from) {
    const match = from.match(/<(.+?)>/);
    return match ? match[1] : from;
  }

  /**
   * Strip HTML tags from email body
   */
  stripHtml(html) {
    if (!html) return "";
    return html
      .replace(/<style[^>]*>.*?<\/style>/gi, "")
      .replace(/<script[^>]*>.*?<\/script>/gi, "")
      .replace(/<[^>]+>/g, " ")
      .replace(/\s+/g, " ")
      .trim();
  }

  /**
   * Detect priority from email content
   */
  detectPriorityFromEmail(text, subject) {
    const content = (text + " " + subject).toLowerCase();
    const criticalKeywords = ["urgent", "critical", "emergency", "down", "outage", "broken"];
    const highKeywords = ["important", "asap", "help", "issue", "problem"];

    if (criticalKeywords.some(kw => content.includes(kw))) return "critical";
    if (highKeywords.some(kw => content.includes(kw))) return "high";
    return "medium";
  }

  /**
   * Process email attachments
   */
  async processAttachments(ticketId, attachments) {
    if (!this.db.attachments[ticketId]) this.db.attachments[ticketId] = [];

    for (const att of attachments) {
      const attachment = {
        id: require("uuid").v4(),
        ticketId,
        filename: att.filename || att.name || "attachment",
        size: att.size || 0,
        mimetype: att.type || att.contentType || "application/octet-stream",
        data: att.content || att.data || "",
        uploadedBy: "system",
        uploaderName: "Email System",
        uploadedAt: new Date().toISOString(),
      };
      this.db.attachments[ticketId].push(attachment);
    }
  }

  /**
   * Send auto-reply email
   */
  async sendAutoReply(ticket) {
    const subject = `Re: ${ticket.title}`;
    const body = `Hi ${ticket.customer},

Thank you for contacting us. We've received your message and created ticket ${ticket.id}.

Our support team will review your request and get back to you as soon as possible.

Best regards,
Support Team`;

    return await this.sendEmail(
      ticket.orgId,
      ticket.emailReplyTo,
      subject,
      body,
      ticket.emailMessageId
    );
  }

  /**
   * Send agent reply via email
   */
  async sendReply(ticket, message) {
    if (!ticket.emailReplyTo) {
      throw new Error("Ticket not from email");
    }

    const subject = `Re: ${ticket.title}`;
    const body = `${message.body}

---
Ticket: ${ticket.id}
Status: ${ticket.status}`;

    return await this.sendEmail(
      ticket.orgId,
      ticket.emailReplyTo,
      subject,
      body,
      ticket.emailMessageId
    );
  }

  /**
   * Send email via SMTP or API
   */
  async sendEmail(orgId, to, subject, body, inReplyTo = null) {
    const integration = this.db.integrations[orgId]?.email;
    if (!integration?.connected) {
      throw new Error("Email not configured");
    }

    const headers = {
      "From": integration.config.fromAddress || "support@example.com",
      "To": to,
      "Subject": subject,
      "Message-ID": `<${require("uuid").v4()}@supportos.local>`,
    };

    if (inReplyTo) {
      headers["In-Reply-To"] = inReplyTo;
      headers["References"] = inReplyTo;
    }

    // In production, use nodemailer or email API
    // const transporter = nodemailer.createTransport({
    //   host: integration.config.smtpHost,
    //   port: integration.config.smtpPort,
    //   auth: {
    //     user: integration.config.smtpUser,
    //     pass: integration.config.smtpPass,
    //   },
    // });
    // await transporter.sendMail({
    //   from: headers["From"],
    //   to: headers["To"],
    //   subject: headers["Subject"],
    //   text: body,
    //   headers,
    // });

    // Mock send
    console.log(`[EMAIL] Sending to ${to}:`);
    console.log(`Subject: ${subject}`);
    console.log(`Body: ${body}`);
    console.log(`Headers:`, headers);

    return { ok: true, messageId: headers["Message-ID"] };
  }

  /**
   * Send internal notification (Slack, webhook, etc.)
   */
  async sendInternalNotification(orgId, ticket, message) {
    // Could trigger Slack notification here
    console.log(`[INTERNAL] ${message} - Ticket ${ticket.id}`);
  }

  generateTicketId(orgId) {
    const tickets = this.db.tickets.filter(t => t.orgId === orgId);
    const nums = tickets.map(t => parseInt(t.id.split("-")[1]) || 0);
    return `TKT-${Math.max(0, ...nums) + 1}`;
  }
}

// ─── Export ───────────────────────────────────────────────────────────────────

module.exports = {
  SlackIntegration,
  EmailIntegration,
};
