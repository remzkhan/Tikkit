/**
 * SupportOS API Server
 * Multi-tenant support ticketing REST API
 * Run: npm install && npm start (port 3001)
 * Demo login: admin@acme.com / password
 */

const express = require("express");
const cors = require("cors");
const jwt = require("jsonwebtoken");
const bcrypt = require("bcryptjs");
const multer = require("multer");
const { v4: uuid } = require("uuid");
const { SlackIntegration, EmailIntegration } = require("./integrations");

const app = express();
const PORT = 3001;
const JWT_SECRET = "supportos-dev-secret-change-in-prod";

app.use(cors({ origin: "*" }));
app.use(express.json());
app.use(express.urlencoded({ extended: true })); // For form data from email webhooks

const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 20 * 1024 * 1024 } });

// ─── Seed Data ───────────────────────────────────────────────────────────────

const HASH = (p) => bcrypt.hashSync(p, 8);
const now = () => new Date().toISOString();
const ago = (min) => new Date(Date.now() - min * 60000).toISOString();

const db = {
  orgs: [
    { id: "org-1", name: "Acme Corp", slug: "acme", plan: "enterprise", seats: 50, usedSeats: 5, domain: "acme.com", logo: null, createdAt: ago(10000), trialEnds: null, stripeCustomerId: "cus_mock_001" },
    { id: "org-2", name: "Beta Labs", slug: "beta-labs", plan: "pro", seats: 10, usedSeats: 2, domain: "betalabs.io", logo: null, createdAt: ago(5000), trialEnds: null, stripeCustomerId: "cus_mock_002" },
  ],
  users: [
    { id: "u-1", email: "admin@acme.com", password: HASH("password"), name: "Aria Chen",    avatar: "AC", role: "admin",  orgIds: ["org-1"], currentOrgId: "org-1", status: "online", createdAt: ago(8000) },
    { id: "u-2", email: "marcus@acme.com",password: HASH("password"), name: "Marcus Webb",  avatar: "MW", role: "agent",  orgIds: ["org-1"], currentOrgId: "org-1", status: "online", createdAt: ago(7000) },
    { id: "u-3", email: "priya@acme.com", password: HASH("password"), name: "Priya Singh",  avatar: "PS", role: "agent",  orgIds: ["org-1"], currentOrgId: "org-1", status: "busy",   createdAt: ago(6000) },
    { id: "u-4", email: "leo@acme.com",   password: HASH("password"), name: "Leo Torres",   avatar: "LT", role: "agent",  orgIds: ["org-1"], currentOrgId: "org-1", status: "away",   createdAt: ago(5000) },
    { id: "u-5", email: "zoe@acme.com",   password: HASH("password"), name: "Zoe Kim",      avatar: "ZK", role: "viewer", orgIds: ["org-1"], currentOrgId: "org-1", status: "online", createdAt: ago(4000) },
    { id: "u-6", email: "admin@beta.com", password: HASH("password"), name: "Beta Admin",   avatar: "BA", role: "admin",  orgIds: ["org-2"], currentOrgId: "org-2", status: "online", createdAt: ago(3000) },
  ],
  invites: [],
  tickets: [
    { id: "TKT-1089", orgId: "org-1", title: "Production DB connection timeout causing 503s",           channel: "slack",    priority: "critical", status: "open",     assigneeId: "u-1", tags: ["backend","prod"],       customer: "Stripe Inc.",  customerEmail: "ops@stripe.com",       sla: 8,   slaPct: 92, jira: "ENG-4421",  unread: true,  createdAt: ago(2),   updatedAt: ago(2),  customFields: { productArea: "Platform Core", severity: "P1", tier: "Enterprise", contractValue: "$240k" } },
    { id: "TKT-1088", orgId: "org-1", title: "OAuth 2.0 token refresh failing for enterprise SSO",      channel: "email",    priority: "critical", status: "open",     assigneeId: "u-3", tags: ["auth","enterprise"],    customer: "Shopify",      customerEmail: "security@shopify.com", sla: 45,  slaPct: 75, linear: "SEC-201", unread: true,  createdAt: ago(14),  updatedAt: ago(10), customFields: { productArea: "Auth", severity: "P1", tier: "Enterprise", contractValue: "$180k" } },
    { id: "TKT-1087", orgId: "org-1", title: "Bulk CSV import silently dropping rows over 10k",         channel: "email",    priority: "high",     status: "pending",  assigneeId: "u-2", tags: ["import","data"],        customer: "Notion HQ",    customerEmail: "data@notion.so",       sla: 120, slaPct: 60, jira: "DATA-889",  unread: false, createdAt: ago(38),  updatedAt: ago(20), customFields: { productArea: "Import", severity: "P2", tier: "Business", contractValue: "$60k" } },
    { id: "TKT-1086", orgId: "org-1", title: "Webhook payloads missing custom field mappings",           channel: "teams",    priority: "high",     status: "open",     assigneeId: null,  tags: ["webhooks","api"],       customer: "Airtable",     customerEmail: "dev@airtable.com",     sla: 240, slaPct: 45, jira: null,        unread: true,  createdAt: ago(60),  updatedAt: ago(60), customFields: { productArea: "API", severity: "P2", tier: "Business", contractValue: "$45k" } },
    { id: "TKT-1085", orgId: "org-1", title: "Dashboard charts not rendering on Safari 17",             channel: "email",    priority: "medium",   status: "open",     assigneeId: "u-5", tags: ["frontend","safari"],    customer: "Figma",        customerEmail: "support@figma.com",    sla: 480, slaPct: 30, jira: null,        unread: false, createdAt: ago(120), updatedAt: ago(120),customFields: { productArea: "Frontend", severity: "P3", tier: "Enterprise", contractValue: "$200k" } },
    { id: "TKT-1084", orgId: "org-1", title: "Scheduled reports not sending to distribution lists",     channel: "whatsapp", priority: "medium",   status: "on-hold",  assigneeId: "u-4", tags: ["reports","email"],      customer: "HubSpot",      customerEmail: "cs@hubspot.com",       sla: 480, slaPct: 20, jira: null,        unread: false, createdAt: ago(180), updatedAt: ago(180),customFields: { productArea: "Reports", severity: "P3", tier: "Business", contractValue: "$90k" } },
    { id: "TKT-1083", orgId: "org-1", title: "Two-factor auth codes not arriving via SMS",              channel: "slack",    priority: "high",     status: "pending",  assigneeId: "u-1", tags: ["2fa","sms"],            customer: "Vercel",       customerEmail: "infra@vercel.com",     sla: 240, slaPct: 15, linear: "SEC-198", unread: false, createdAt: ago(240), updatedAt: ago(240),customFields: { productArea: "Auth", severity: "P2", tier: "Enterprise", contractValue: "$120k" } },
    { id: "TKT-1082", orgId: "org-1", title: "API rate limiter blocking legitimate enterprise traffic", channel: "email",    priority: "high",     status: "open",     assigneeId: "u-3", tags: ["api","rate-limit"],     customer: "Twilio",       customerEmail: "platform@twilio.com",  sla: 360, slaPct: 10, jira: "API-672",   unread: false, createdAt: ago(300), updatedAt: ago(300),customFields: { productArea: "API", severity: "P2", tier: "Enterprise", contractValue: "$300k" } },
    { id: "TKT-1081", orgId: "org-1", title: "Audit log export returns empty for date ranges >30d",     channel: "email",    priority: "medium",   status: "open",     assigneeId: null,  tags: ["audit","export"],       customer: "Okta",         customerEmail: "compliance@okta.com",  sla: 480, slaPct: 5,  jira: null,        unread: false, createdAt: ago(360), updatedAt: ago(360),customFields: { productArea: "Compliance", severity: "P3", tier: "Enterprise", contractValue: "$250k" } },
    { id: "TKT-1080", orgId: "org-1", title: "Workflow automation triggers firing twice on edit events",channel: "teams",    priority: "medium",   status: "resolved", assigneeId: "u-2", tags: ["automation","bugs"],    customer: "Monday.com",   customerEmail: "eng@monday.com",       sla: 480, slaPct: 0,  jira: "WF-341",    unread: false, createdAt: ago(480), updatedAt: ago(480),customFields: { productArea: "Automation", severity: "P3", tier: "Business", contractValue: "$75k" } },
  ],
  messages: {
    "TKT-1089": [
      { id: uuid(), ticketId: "TKT-1089", type: "customer", authorName: "Stripe Ops", authorEmail: "ops@stripe.com", body: "We're seeing persistent 503s across our integration layer — looks like DB timeouts. This is affecting production traffic right now.", attachments: [], createdAt: ago(2) },
      { id: uuid(), ticketId: "TKT-1089", type: "agent",    authorId: "u-1", authorName: "Aria Chen",  body: "On it — I've flagged this as P1 and looped in platform engineering. Can you share the error trace you're seeing?", attachments: [], createdAt: ago(1) },
      { id: uuid(), ticketId: "TKT-1089", type: "internal", authorId: "u-1", authorName: "Aria Chen",  body: "Looks like connection pool exhaustion. Deploy v2.4.1 yesterday likely introduced a connection leak. Reviewing rollback options with @Marcus.", attachments: [], createdAt: ago(1) },
    ],
    "TKT-1088": [
      { id: uuid(), ticketId: "TKT-1088", type: "customer", authorName: "Shopify Security", authorEmail: "security@shopify.com", body: "Enterprise SSO tokens are failing to refresh after 1 hour. Users getting logged out. Urgent for our compliance posture.", attachments: [], createdAt: ago(14) },
      { id: uuid(), ticketId: "TKT-1088", type: "agent",    authorId: "u-3", authorName: "Priya Singh", body: "Confirmed the issue. OAuth PKCE flow seems to be sending expired tokens to the refresh endpoint. Investigating token rotation logic.", attachments: [], createdAt: ago(12) },
    ],
  },
  attachments: {},
  integrations: {
    "org-1": {
      jira:       { connected: true,  connectedAt: ago(5000), config: { baseUrl: "https://acme.atlassian.net", apiKey: "••••3f2a", project: "ENG", syncDirection: "Bidirectional", autoCreate: true } },
      linear:     { connected: true,  connectedAt: ago(4000), config: { apiKey: "lin_api_••••8c1e", team: "Support", syncDirection: "Push only", autoCreate: false } },
      slack:      { connected: true,  connectedAt: ago(3000), config: { workspace: "Acme HQ", botToken: "xoxb-••••", notifyOn: "critical,high", channel: "#support-alerts", autoReply: true } },
      teams:      { connected: true,  connectedAt: ago(2000), config: { tenant: "acme.onmicrosoft.com", webhookUrl: "https://acme.webhook.office.com/••••", channel: "Support Ops" } },
      whatsapp:   { connected: true,  connectedAt: ago(1000), config: { phoneNumber: "+1 555-000-0000", businessId: "••••••••", autoReply: true } },
      email:      { connected: true,  connectedAt: ago(4500), config: { provider: "sendgrid", fromAddress: "support@acme.com", fromName: "Acme Support", smtpHost: "smtp.sendgrid.net", smtpPort: 587, autoReply: true } },
      zoom:       { connected: true,  connectedAt: ago(500),  config: { accountId: "••••••••", clientId: "••••••••", autoRecord: false } },
      github:     { connected: false, config: {} },
      gcal:       { connected: false, config: {} },
      pagerduty:  { connected: false, config: {} },
      salesforce: { connected: false, config: {} },
      zendesk:    { connected: false, config: {} },
      intercom:   { connected: false, config: {} },
    },
    "org-2": {
      jira:    { connected: false, config: {} },
      slack:   { connected: true, connectedAt: ago(100), config: { workspace: "Beta Labs", botToken: "xoxb-••••", notifyOn: "critical", channel: "#bugs", autoReply: false } },
      linear:  { connected: true, connectedAt: ago(200), config: { apiKey: "lin_api_••••beta", team: "Engineering", syncDirection: "Bidirectional", autoCreate: true } },
      teams:   { connected: false, config: {} },
      whatsapp:{ connected: false, config: {} },
      email:   { connected: false, config: {} },
      zoom:    { connected: false, config: {} },
      github:  { connected: true, connectedAt: ago(300), config: { org: "betalabs", repo: "core", webhookSecret: "••••••••" } },
      gcal:    { connected: false, config: {} },
      pagerduty: { connected: false, config: {} },
      salesforce:{ connected: false, config: {} },
      zendesk:  { connected: false, config: {} },
      intercom: { connected: false, config: {} },
    }
  },
  billing: {
    "org-1": { plan: "enterprise", interval: "annual",  amount: 1188, nextBillingDate: "2027-01-01", paymentMethod: { brand: "Visa", last4: "4242" }, invoices: [
      { id: "inv-001", date: "2026-01-01", amount: 1188, status: "paid" },
      { id: "inv-002", date: "2025-01-01", amount: 1188, status: "paid" },
    ]},
    "org-2": { plan: "pro",        interval: "monthly", amount: 99,   nextBillingDate: "2026-03-17", paymentMethod: { brand: "Mastercard", last4: "5555" }, invoices: [
      { id: "inv-101", date: "2026-02-17", amount: 99, status: "paid" },
    ]},
  },
};

// ─── Integration Handlers ─────────────────────────────────────────────────────
const slackIntegration = new SlackIntegration(db);
const emailIntegration = new EmailIntegration(db);

// Seed messages for remaining tickets
db.tickets.forEach(t => {
  if (!db.messages[t.id]) {
    db.messages[t.id] = [
      { id: uuid(), ticketId: t.id, type: "customer", authorName: t.customer, authorEmail: t.customerEmail, body: `We are experiencing: ${t.title}. Please advise urgently.`, attachments: [], createdAt: t.createdAt },
    ];
  }
  if (!db.attachments[t.id]) db.attachments[t.id] = [];
});

// ─── Auth Middleware ──────────────────────────────────────────────────────────

function auth(req, res, next) {
  const h = req.headers.authorization;
  if (!h || !h.startsWith("Bearer ")) return res.status(401).json({ error: "Unauthorized" });
  try {
    req.user = jwt.verify(h.slice(7), JWT_SECRET);
    const user = db.users.find(u => u.id === req.user.id);
    if (!user) return res.status(401).json({ error: "User not found" });
    req.userDoc = user;
    req.orgId = user.currentOrgId;
    next();
  } catch { res.status(401).json({ error: "Invalid token" }); }
}

function adminOnly(req, res, next) {
  if (req.userDoc.role !== "admin") return res.status(403).json({ error: "Admin only" });
  next();
}

function safeUser(u) {
  const { password, ...rest } = u;
  return { ...rest, tickets: db.tickets.filter(t => t.orgId === u.currentOrgId && t.assigneeId === u.id).length };
}

// ─── Auth Routes ──────────────────────────────────────────────────────────────

app.post("/api/auth/login", async (req, res) => {
  const { email, password } = req.body;
  if (!email || !password) return res.status(400).json({ error: "Email and password required" });
  const user = db.users.find(u => u.email.toLowerCase() === email.toLowerCase());
  if (!user || !bcrypt.compareSync(password, user.password))
    return res.status(401).json({ error: "Invalid credentials" });
  const token = jwt.sign({ id: user.id }, JWT_SECRET, { expiresIn: "7d" });
  const orgs = db.orgs.filter(o => user.orgIds.includes(o.id));
  res.json({ token, user: safeUser(user), orgs });
});

app.post("/api/auth/signup", async (req, res) => {
  const { name, email, password, orgName } = req.body;
  if (!name || !email || !password || !orgName) return res.status(400).json({ error: "All fields required" });
  if (db.users.find(u => u.email.toLowerCase() === email.toLowerCase()))
    return res.status(409).json({ error: "Email already registered" });

  const org = { id: `org-${uuid()}`, name: orgName, slug: orgName.toLowerCase().replace(/\s+/g, "-"), plan: "free", seats: 3, usedSeats: 1, domain: email.split("@")[1], logo: null, createdAt: now(), trialEnds: new Date(Date.now() + 14 * 86400000).toISOString(), stripeCustomerId: null };
  const user = { id: `u-${uuid()}`, email, password: HASH(password), name, avatar: name.split(" ").map(w=>w[0]).join("").toUpperCase().slice(0,2), role: "admin", orgIds: [org.id], currentOrgId: org.id, status: "online", createdAt: now() };

  db.orgs.push(org);
  db.users.push(user);
  db.integrations[org.id] = { jira:{connected:false,config:{}}, linear:{connected:false,config:{}}, slack:{connected:false,config:{}}, teams:{connected:false,config:{}}, whatsapp:{connected:false,config:{}}, zoom:{connected:false,config:{}}, github:{connected:false,config:{}}, gcal:{connected:false,config:{}}, pagerduty:{connected:false,config:{}}, salesforce:{connected:false,config:{}}, zendesk:{connected:false,config:{}}, intercom:{connected:false,config:{}} };
  db.billing[org.id] = { plan: "free", interval: "monthly", amount: 0, nextBillingDate: null, paymentMethod: null, invoices: [] };

  const token = jwt.sign({ id: user.id }, JWT_SECRET, { expiresIn: "7d" });
  res.status(201).json({ token, user: safeUser(user), orgs: [org] });
});

app.post("/api/auth/invite/accept", async (req, res) => {
  const { token: inviteToken, name, password } = req.body;
  const invite = db.invites.find(i => i.token === inviteToken && !i.acceptedAt && new Date(i.expiresAt) > new Date());
  if (!invite) return res.status(400).json({ error: "Invalid or expired invite" });

  let user = db.users.find(u => u.email.toLowerCase() === invite.email.toLowerCase());
  if (user) {
    if (!user.orgIds.includes(invite.orgId)) user.orgIds.push(invite.orgId);
    user.currentOrgId = invite.orgId;
    if (invite.role) user.role = invite.role;
  } else {
    user = { id: `u-${uuid()}`, email: invite.email, password: HASH(password || "changeme"), name: name || invite.email.split("@")[0], avatar: (name||"??").split(" ").map(w=>w[0]).join("").toUpperCase().slice(0,2), role: invite.role || "agent", orgIds: [invite.orgId], currentOrgId: invite.orgId, status: "offline", createdAt: now() };
    db.users.push(user);
    const org = db.orgs.find(o=>o.id===invite.orgId);
    if (org) org.usedSeats++;
  }
  invite.acceptedAt = now();
  const jwtToken = jwt.sign({ id: user.id }, JWT_SECRET, { expiresIn: "7d" });
  res.json({ token: jwtToken, user: safeUser(user), orgs: db.orgs.filter(o => user.orgIds.includes(o.id)) });
});

// ─── User / Org Routes ────────────────────────────────────────────────────────

app.get("/api/me", auth, (req, res) => {
  const orgs = db.orgs.filter(o => req.userDoc.orgIds.includes(o.id));
  res.json({ user: safeUser(req.userDoc), orgs, currentOrg: db.orgs.find(o => o.id === req.orgId) });
});

app.patch("/api/me", auth, (req, res) => {
  const { name, status } = req.body;
  if (name) req.userDoc.name = name;
  if (status) req.userDoc.status = status;
  res.json({ user: safeUser(req.userDoc) });
});

app.post("/api/orgs/switch", auth, (req, res) => {
  const { orgId } = req.body;
  if (!req.userDoc.orgIds.includes(orgId)) return res.status(403).json({ error: "Not a member" });
  req.userDoc.currentOrgId = orgId;
  const token = jwt.sign({ id: req.userDoc.id }, JWT_SECRET, { expiresIn: "7d" });
  res.json({ token, user: safeUser(req.userDoc), org: db.orgs.find(o => o.id === orgId) });
});

app.patch("/api/orgs/:orgId", auth, adminOnly, (req, res) => {
  const org = db.orgs.find(o => o.id === req.params.orgId && o.id === req.orgId);
  if (!org) return res.status(404).json({ error: "Org not found" });
  const { name, domain } = req.body;
  if (name) org.name = name;
  if (domain) org.domain = domain;
  res.json({ org });
});

// ─── Team Routes ──────────────────────────────────────────────────────────────

app.get("/api/team", auth, (req, res) => {
  const members = db.users.filter(u => u.orgIds.includes(req.orgId)).map(safeUser);
  const pendingInvites = db.invites.filter(i => i.orgId === req.orgId && !i.acceptedAt && new Date(i.expiresAt) > new Date());
  res.json({ members, pendingInvites });
});

app.post("/api/team/invite", auth, adminOnly, (req, res) => {
  const { email, role = "agent" } = req.body;
  if (!email) return res.status(400).json({ error: "Email required" });
  const org = db.orgs.find(o => o.id === req.orgId);
  if (org.usedSeats >= org.seats) return res.status(400).json({ error: "Seat limit reached. Please upgrade your plan." });
  const existing = db.invites.find(i => i.email.toLowerCase() === email.toLowerCase() && i.orgId === req.orgId && !i.acceptedAt);
  if (existing) return res.status(409).json({ error: "Invite already pending" });
  const invite = { id: uuid(), orgId: req.orgId, email, role, token: uuid(), invitedBy: req.userDoc.id, createdAt: now(), expiresAt: new Date(Date.now() + 7 * 86400000).toISOString(), acceptedAt: null };
  db.invites.push(invite);
  res.status(201).json({ invite, inviteUrl: `http://localhost:5173/accept-invite/${invite.token}` });
});

app.patch("/api/team/:userId", auth, adminOnly, (req, res) => {
  const member = db.users.find(u => u.id === req.params.userId && u.orgIds.includes(req.orgId));
  if (!member) return res.status(404).json({ error: "Member not found" });
  const { role, status } = req.body;
  if (role) member.role = role;
  if (status) member.status = status;
  res.json({ user: safeUser(member) });
});

app.delete("/api/team/:userId", auth, adminOnly, (req, res) => {
  const member = db.users.find(u => u.id === req.params.userId && u.orgIds.includes(req.orgId));
  if (!member) return res.status(404).json({ error: "Member not found" });
  if (member.id === req.userDoc.id) return res.status(400).json({ error: "Cannot remove yourself" });
  member.orgIds = member.orgIds.filter(id => id !== req.orgId);
  const org = db.orgs.find(o => o.id === req.orgId);
  if (org && org.usedSeats > 0) org.usedSeats--;
  res.json({ success: true });
});

app.delete("/api/team/invites/:inviteId", auth, adminOnly, (req, res) => {
  const idx = db.invites.findIndex(i => i.id === req.params.inviteId && i.orgId === req.orgId);
  if (idx < 0) return res.status(404).json({ error: "Invite not found" });
  db.invites.splice(idx, 1);
  res.json({ success: true });
});

// ─── Ticket Routes ────────────────────────────────────────────────────────────

function ticketSeq(orgId) {
  const nums = db.tickets.filter(t=>t.orgId===orgId).map(t=>parseInt(t.id.split("-")[1])||0);
  return `TKT-${Math.max(0,...nums)+1}`;
}

app.get("/api/tickets", auth, (req, res) => {
  let tickets = db.tickets.filter(t => t.orgId === req.orgId);
  const { status, priority, channel, assigneeId, q } = req.query;
  if (status)     tickets = tickets.filter(t => t.status === status);
  if (priority)   tickets = tickets.filter(t => t.priority === priority);
  if (channel)    tickets = tickets.filter(t => t.channel === channel);
  if (assigneeId) tickets = tickets.filter(t => t.assigneeId === assigneeId);
  if (q) { const ql = q.toLowerCase(); tickets = tickets.filter(t => t.title.toLowerCase().includes(ql) || t.id.toLowerCase().includes(ql) || t.customer.toLowerCase().includes(ql)); }
  tickets = tickets.sort((a,b) => new Date(b.createdAt) - new Date(a.createdAt));
  const enriched = tickets.map(t => ({
    ...t,
    assignee: t.assigneeId ? safeUser(db.users.find(u=>u.id===t.assigneeId)||{}) : null,
    messageCount: (db.messages[t.id]||[]).filter(m=>m.type!=="internal").length,
    attachmentCount: (db.attachments[t.id]||[]).length,
  }));
  res.json({ tickets: enriched, total: enriched.length });
});

app.post("/api/tickets", auth, (req, res) => {
  const { title, channel, priority, status, assigneeId, customer, customerEmail, tags, customFields, description } = req.body;
  if (!title || !channel || !priority) return res.status(400).json({ error: "title, channel, priority required" });
  const ticket = {
    id: ticketSeq(req.orgId), orgId: req.orgId, title, channel, priority, status: status||"open",
    assigneeId: assigneeId||null, tags: tags||[], customer: customer||"Unknown", customerEmail: customerEmail||"",
    sla: priority==="critical"?8:priority==="high"?240:priority==="medium"?480:960, slaPct: 0,
    jira: null, linear: null, unread: true, createdAt: now(), updatedAt: now(),
    customFields: customFields||{ productArea:"", severity:"P3", tier:"", contractValue:"" },
  };
  db.tickets.push(ticket);
  db.messages[ticket.id] = [];
  db.attachments[ticket.id] = [];
  if (description) {
    db.messages[ticket.id].push({ id: uuid(), ticketId: ticket.id, type: "customer", authorName: customer||"Customer", authorEmail: customerEmail||"", body: description, attachments: [], createdAt: now() });
  }
  res.status(201).json({ ticket: { ...ticket, assignee: ticket.assigneeId ? safeUser(db.users.find(u=>u.id===ticket.assigneeId)) : null, messageCount: 0, attachmentCount: 0 } });
});

app.get("/api/tickets/:id", auth, (req, res) => {
  const ticket = db.tickets.find(t => t.id === req.params.id && t.orgId === req.orgId);
  if (!ticket) return res.status(404).json({ error: "Not found" });
  ticket.unread = false;
  res.json({
    ticket: { ...ticket, assignee: ticket.assigneeId ? safeUser(db.users.find(u=>u.id===ticket.assigneeId)) : null },
    messages: (db.messages[ticket.id]||[]),
    attachments: (db.attachments[ticket.id]||[]).map(a => ({ ...a, data: undefined, url: `/api/tickets/${ticket.id}/attachments/${a.id}` })),
  });
});

app.patch("/api/tickets/:id", auth, (req, res) => {
  const ticket = db.tickets.find(t => t.id === req.params.id && t.orgId === req.orgId);
  if (!ticket) return res.status(404).json({ error: "Not found" });
  const allowed = ["title","status","priority","assigneeId","tags","customFields","jira","linear","sla","slaPct"];
  allowed.forEach(k => { if (req.body[k] !== undefined) ticket[k] = req.body[k]; });
  ticket.updatedAt = now();
  res.json({ ticket: { ...ticket, assignee: ticket.assigneeId ? safeUser(db.users.find(u=>u.id===ticket.assigneeId)) : null } });
});

app.delete("/api/tickets/:id", auth, adminOnly, (req, res) => {
  const idx = db.tickets.findIndex(t => t.id === req.params.id && t.orgId === req.orgId);
  if (idx < 0) return res.status(404).json({ error: "Not found" });
  db.tickets.splice(idx, 1);
  res.json({ success: true });
});

// ─── Messages ─────────────────────────────────────────────────────────────────

app.get("/api/tickets/:id/messages", auth, (req, res) => {
  const ticket = db.tickets.find(t => t.id === req.params.id && t.orgId === req.orgId);
  if (!ticket) return res.status(404).json({ error: "Not found" });
  res.json({ messages: db.messages[ticket.id]||[] });
});

app.post("/api/tickets/:id/messages", auth, async (req, res) => {
  const ticket = db.tickets.find(t => t.id === req.params.id && t.orgId === req.orgId);
  if (!ticket) return res.status(404).json({ error: "Not found" });
  const { body, type = "agent" } = req.body;
  if (!body?.trim()) return res.status(400).json({ error: "Message body required" });
  const msg = { id: uuid(), ticketId: ticket.id, type, authorId: req.userDoc.id, authorName: req.userDoc.name, body: body.trim(), attachments: [], createdAt: now() };
  if (!db.messages[ticket.id]) db.messages[ticket.id] = [];
  db.messages[ticket.id].push(msg);
  ticket.updatedAt = now();
  if (type === "agent") ticket.unread = false;
  
  // Send reply via appropriate channel
  if (type === "agent") {
    try {
      if (ticket.channel === "slack" && ticket.slackThreadTs) {
        await slackIntegration.sendReply(ticket, msg);
      } else if (ticket.channel === "email" && ticket.emailReplyTo) {
        await emailIntegration.sendReply(ticket, msg);
      }
    } catch (error) {
      console.error(`[SEND REPLY ERROR]`, error);
      // Don't fail the request if external send fails
    }
  }
  
  res.status(201).json({ message: msg });
});

// ─── Attachments ──────────────────────────────────────────────────────────────

app.post("/api/tickets/:id/attachments", auth, upload.array("files", 10), (req, res) => {
  const ticket = db.tickets.find(t => t.id === req.params.id && t.orgId === req.orgId);
  if (!ticket) return res.status(404).json({ error: "Not found" });
  if (!req.files?.length) return res.status(400).json({ error: "No files uploaded" });
  if (!db.attachments[ticket.id]) db.attachments[ticket.id] = [];
  const saved = req.files.map(f => {
    const att = { id: uuid(), ticketId: ticket.id, filename: f.originalname, size: f.size, mimetype: f.mimetype, data: f.buffer.toString("base64"), uploadedBy: req.userDoc.id, uploaderName: req.userDoc.name, uploadedAt: now() };
    db.attachments[ticket.id].push(att);
    return { ...att, data: undefined, url: `/api/tickets/${ticket.id}/attachments/${att.id}` };
  });
  ticket.updatedAt = now();
  res.status(201).json({ attachments: saved });
});

app.get("/api/tickets/:id/attachments/:attId", auth, (req, res) => {
  const atts = db.attachments[req.params.id]||[];
  const att = atts.find(a => a.id === req.params.attId);
  if (!att) return res.status(404).json({ error: "Not found" });
  const buf = Buffer.from(att.data, "base64");
  res.set({ "Content-Type": att.mimetype, "Content-Disposition": `attachment; filename="${att.filename}"`, "Content-Length": buf.length });
  res.send(buf);
});

app.delete("/api/tickets/:id/attachments/:attId", auth, (req, res) => {
  const atts = db.attachments[req.params.id]||[];
  const idx = atts.findIndex(a => a.id === req.params.attId);
  if (idx < 0) return res.status(404).json({ error: "Not found" });
  atts.splice(idx, 1);
  res.json({ success: true });
});

// ─── Integrations ─────────────────────────────────────────────────────────────

app.get("/api/integrations", auth, (req, res) => {
  const ints = db.integrations[req.orgId] || {};
  res.json({ integrations: ints });
});

app.post("/api/integrations/:intId/connect", auth, adminOnly, (req, res) => {
  const { intId } = req.params;
  if (!db.integrations[req.orgId]) return res.status(404).json({ error: "Org not found" });
  const { config } = req.body;
  if (!config) return res.status(400).json({ error: "Config required" });
  // Validate required fields based on integration type
  const required = { jira:["baseUrl","apiKey","project"], linear:["apiKey","team"], slack:["botToken","channel"], teams:["tenant","webhookUrl"], whatsapp:["phoneNumber","businessId"], zoom:["accountId","clientId"], github:["org","repo","webhookSecret"], gcal:["calendar","serviceAccount"], pagerduty:["routingKey"], salesforce:["instanceUrl","username","password"], zendesk:["subdomain","apiToken","adminEmail"], intercom:["appId","apiKey"] };
  const missing = (required[intId]||[]).filter(k => !config[k]);
  if (missing.length) return res.status(400).json({ error: `Missing required fields: ${missing.join(", ")}` });
  // Mask secrets
  const masked = { ...config };
  ["apiKey","botToken","webhookSecret","password","routingKey"].forEach(k => { if (masked[k]) masked[k] = masked[k].slice(-4).padStart(masked[k].length, "•"); });
  db.integrations[req.orgId][intId] = { connected: true, connectedAt: now(), config: masked };
  res.json({ integration: db.integrations[req.orgId][intId] });
});

app.patch("/api/integrations/:intId", auth, adminOnly, (req, res) => {
  const int = db.integrations[req.orgId]?.[req.params.intId];
  if (!int) return res.status(404).json({ error: "Integration not found" });
  const { config } = req.body;
  if (config) int.config = { ...int.config, ...config };
  res.json({ integration: int });
});

app.delete("/api/integrations/:intId/disconnect", auth, adminOnly, (req, res) => {
  if (db.integrations[req.orgId]?.[req.params.intId]) {
    db.integrations[req.orgId][req.params.intId] = { connected: false, config: {} };
  }
  res.json({ success: true });
});

// ─── Billing ──────────────────────────────────────────────────────────────────

const PLANS = {
  free:       { name: "Free",       price: 0,    monthlyPrice: 0,    seats: 3,   features: ["3 agents","500 tickets/mo","Email channel","Basic reports"] },
  pro:        { name: "Pro",        price: 99,   monthlyPrice: 99,   seats: 10,  features: ["10 agents","Unlimited tickets","All channels","Advanced reports","SLA management","API access"] },
  business:   { name: "Business",   price: 299,  monthlyPrice: 299,  seats: 25,  features: ["25 agents","Everything in Pro","Custom integrations","Priority support","Audit logs","Custom fields"] },
  enterprise: { name: "Enterprise", price: 999,  monthlyPrice: 999,  seats: 999, features: ["Unlimited agents","Everything in Business","SSO/SAML","Dedicated CSM","Custom SLA","On-prem option","99.99% SLA"] },
};

app.get("/api/billing", auth, adminOnly, (req, res) => {
  const billing = db.billing[req.orgId] || {};
  const org = db.orgs.find(o => o.id === req.orgId);
  res.json({ billing, plans: PLANS, currentPlan: PLANS[org?.plan||"free"], org });
});

app.post("/api/billing/upgrade", auth, adminOnly, (req, res) => {
  const { plan, interval = "monthly" } = req.body;
  if (!PLANS[plan]) return res.status(400).json({ error: "Invalid plan" });
  const org = db.orgs.find(o => o.id === req.orgId);
  if (!org) return res.status(404).json({ error: "Org not found" });
  org.plan = plan;
  org.seats = PLANS[plan].seats;
  const billing = db.billing[req.orgId] || {};
  const amount = interval === "annual" ? PLANS[plan].price * 10 : PLANS[plan].monthlyPrice;
  billing.plan = plan;
  billing.interval = interval;
  billing.amount = amount;
  billing.nextBillingDate = new Date(Date.now() + (interval==="annual"?365:30) * 86400000).toISOString().split("T")[0];
  if (!billing.invoices) billing.invoices = [];
  billing.invoices.unshift({ id: `inv-${uuid().slice(0,6)}`, date: new Date().toISOString().split("T")[0], amount, status: "paid" });
  db.billing[req.orgId] = billing;
  res.json({ billing, org });
});

// ─── Reports ──────────────────────────────────────────────────────────────────

app.get("/api/reports/overview", auth, (req, res) => {
  const tickets = db.tickets.filter(t => t.orgId === req.orgId);
  const byStatus   = Object.fromEntries(["open","pending","on-hold","resolved","closed"].map(s => [s, tickets.filter(t=>t.status===s).length]));
  const byPriority = Object.fromEntries(["critical","high","medium","low"].map(p => [p, tickets.filter(t=>t.priority===p).length]));
  const byChannel  = Object.fromEntries(["email","slack","teams","whatsapp"].map(c => [c, tickets.filter(t=>t.channel===c).length]));
  const resolved   = tickets.filter(t=>t.status==="resolved"||t.status==="closed");
  const agentStats = db.users.filter(u=>u.orgIds.includes(req.orgId)).map(u=>({
    id: u.id, name: u.name, avatar: u.avatar,
    open: tickets.filter(t=>t.assigneeId===u.id&&t.status==="open").length,
    resolved: resolved.filter(t=>t.assigneeId===u.id).length,
    total: tickets.filter(t=>t.assigneeId===u.id).length,
  }));
  // Simulated daily volume for last 14 days
  const volume = Array.from({length:14},(_,i)=>({ date: new Date(Date.now()-(13-i)*86400000).toISOString().split("T")[0], created: Math.floor(Math.random()*20+5), resolved: Math.floor(Math.random()*15+3) }));
  res.json({ byStatus, byPriority, byChannel, agentStats, volume, totals: { tickets: tickets.length, open: byStatus.open, resolved: resolved.length, avgResponseTime: "18m", slaBreaches: Math.floor(tickets.length * 0.08) } });
});

// ─── Customers ────────────────────────────────────────────────────────────────

app.get("/api/customers", auth, (req, res) => {
  const tickets = db.tickets.filter(t => t.orgId === req.orgId);
  const map = {};
  tickets.forEach(t => {
    if (!map[t.customerEmail]) map[t.customerEmail] = { email: t.customerEmail, name: t.customer, tickets: 0, open: 0, lastSeen: t.updatedAt };
    map[t.customerEmail].tickets++;
    if (t.status === "open") map[t.customerEmail].open++;
    if (t.updatedAt > map[t.customerEmail].lastSeen) map[t.customerEmail].lastSeen = t.updatedAt;
  });
  res.json({ customers: Object.values(map).sort((a,b)=>b.tickets-a.tickets) });
});

// ─── Health ───────────────────────────────────────────────────────────────────

app.get("/api/health", (req, res) => res.json({ status: "ok", version: "1.0.0", timestamp: now() }));

// ─── Integration Webhooks ─────────────────────────────────────────────────────

/**
 * Slack webhook endpoint
 * Configure in Slack App > Event Subscriptions > Request URL
 * URL: https://your-domain.com/api/webhooks/slack/:orgId
 */
app.post("/api/webhooks/slack/:orgId", async (req, res) => {
  const { orgId } = req.params;
  const org = db.orgs.find(o => o.id === orgId);
  
  if (!org) return res.status(404).json({ error: "Org not found" });
  
  const integration = db.integrations[orgId]?.slack;
  if (!integration?.connected) {
    return res.status(400).json({ error: "Slack not connected for this org" });
  }

  try {
    // Verify signature in production
    // if (!slackIntegration.verifySlackSignature(req)) {
    //   return res.status(401).json({ error: "Invalid signature" });
    // }

    const result = await slackIntegration.handleWebhook(req.body, orgId);
    res.json(result);
  } catch (error) {
    console.error("[SLACK WEBHOOK ERROR]", error);
    res.status(500).json({ error: error.message });
  }
});

/**
 * Email webhook endpoint (SendGrid Inbound Parse format)
 * Configure in SendGrid > Settings > Inbound Parse
 * URL: https://your-domain.com/api/webhooks/email/:orgId
 * 
 * Also works with Mailgun, Postmark, etc. with slight format differences
 */
app.post("/api/webhooks/email/:orgId", async (req, res) => {
  const { orgId } = req.params;
  const org = db.orgs.find(o => o.id === orgId);
  
  if (!org) return res.status(404).json({ error: "Org not found" });
  
  const integration = db.integrations[orgId]?.email;
  if (!integration?.connected) {
    return res.status(400).json({ error: "Email not configured for this org" });
  }

  try {
    const result = await emailIntegration.handleIncomingEmail(req.body, orgId);
    res.json(result);
  } catch (error) {
    console.error("[EMAIL WEBHOOK ERROR]", error);
    res.status(500).json({ error: error.message });
  }
});

/**
 * Test endpoint to simulate incoming Slack message
 * POST /api/webhooks/slack/:orgId/test
 */
app.post("/api/webhooks/slack/:orgId/test", async (req, res) => {
  const { orgId } = req.params;
  const { text, user = "U123ABC", channel = "C123ABC" } = req.body;
  
  const testPayload = {
    type: "event_callback",
    event: {
      type: "message",
      user,
      text: text || "Test message from Slack - urgent help needed!",
      channel,
      ts: Date.now().toString(),
    },
  };

  try {
    const result = await slackIntegration.handleWebhook(testPayload, orgId);
    res.json({ success: true, result });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

/**
 * Test endpoint to simulate incoming email
 * POST /api/webhooks/email/:orgId/test
 */
app.post("/api/webhooks/email/:orgId/test", async (req, res) => {
  const { orgId } = req.params;
  const { from, subject, text } = req.body;
  
  const testPayload = {
    from: from || "John Doe <john@customer.com>",
    subject: subject || "Urgent: System not working",
    text: text || "Hi, we're experiencing issues with our system. The dashboard won't load and we're getting 500 errors. This is affecting our entire team. Please help urgently!",
    to: "support@acme.com",
    headers: {
      "Message-ID": `<test-${uuid()}@customer.com>`,
      "Date": new Date().toUTCString(),
    },
    attachments: [],
  };

  try {
    const result = await emailIntegration.handleIncomingEmail(testPayload, orgId);
    res.json({ success: true, result });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.listen(PORT, () => {
  console.log(`\n🚀 SupportOS API running at http://localhost:${PORT}`);
  console.log(`\nDemo accounts (password: "password"):`);
  console.log(`  admin@acme.com  — Acme Corp (Enterprise, Admin)`);
  console.log(`  marcus@acme.com — Acme Corp (Enterprise, Agent)`);
  console.log(`  admin@beta.com  — Beta Labs (Pro, Admin)\n`);
});
