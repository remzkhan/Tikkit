import { useState, useEffect, useRef, createContext, useContext, useCallback } from "react";

// ─── Config ───────────────────────────────────────────────────────────────────
const API = "http://localhost:3001/api";

// ─── Auth Context ─────────────────────────────────────────────────────────────
const AuthCtx = createContext(null);
function useAuth() { return useContext(AuthCtx); }

// ─── API Client Hook ──────────────────────────────────────────────────────────
function useApi() {
  const { token } = useAuth();
  const call = useCallback(async (method, path, body, isForm) => {
    const headers = { Authorization: `Bearer ${token}` };
    if (!isForm) headers["Content-Type"] = "application/json";
    const res = await fetch(`${API}${path}`, { method, headers, body: isForm ? body : body ? JSON.stringify(body) : undefined });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || "Request failed");
    return data;
  }, [token]);
  return {
    get:    (p)    => call("GET",    p),
    post:   (p, b) => call("POST",   p, b),
    patch:  (p, b) => call("PATCH",  p, b),
    del:    (p)    => call("DELETE", p),
    upload: (p, f) => call("POST",   p, f, true),
  };
}

// ─── Toast System ─────────────────────────────────────────────────────────────
const ToastCtx = createContext(null);
function ToastProvider({ children }) {
  const [toasts, setToasts] = useState([]);
  const add = useCallback((msg, type = "info") => {
    const id = Date.now();
    setToasts(t => [...t, { id, msg, type }]);
    setTimeout(() => setToasts(t => t.filter(x => x.id !== id)), 4000);
  }, []);
  return (
    <ToastCtx.Provider value={add}>
      {children}
      <div style={{position:"fixed",bottom:20,right:20,zIndex:9999,display:"flex",flexDirection:"column",gap:8}}>
        {toasts.map(t => (
          <div key={t.id} style={{padding:"10px 16px",borderRadius:8,background:t.type==="error"?"#FF3B3020":t.type==="success"?"#34C75920":"#4F8EF720",border:`1px solid ${t.type==="error"?"#FF3B3060":t.type==="success"?"#34C75960":"#4F8EF760"}`,color:t.type==="error"?"#FF3B30":t.type==="success"?"#34C759":"#4F8EF7",fontSize:13,fontWeight:500,boxShadow:"0 4px 20px #00000060",animation:"slInUp 0.2s ease",maxWidth:320}}>
            {t.type==="success"?"✓ ":t.type==="error"?"✕ ":"ℹ "}{t.msg}
          </div>
        ))}
      </div>
    </ToastCtx.Provider>
  );
}
function useToast() { return useContext(ToastCtx); }

// ─── Static Data ──────────────────────────────────────────────────────────────
const CHANNELS   = { email:{label:"Email",color:"#4F8EF7",icon:"✉"}, slack:{label:"Slack",color:"#E01E5A",icon:"⚡"}, teams:{label:"Teams",color:"#6264A7",icon:"⬡"}, whatsapp:{label:"WhatsApp",color:"#25D366",icon:"◉"} };
const PRIORITIES = { critical:{label:"Critical",color:"#FF3B30",bg:"#FF3B3015"}, high:{label:"High",color:"#FF9500",bg:"#FF950015"}, medium:{label:"Medium",color:"#FFCC00",bg:"#FFCC0015"}, low:{label:"Low",color:"#34C759",bg:"#34C75915"} };
const STATUSES   = { open:{label:"Open",color:"#4F8EF7"}, pending:{label:"Pending",color:"#FF9500"}, "on-hold":{label:"On Hold",color:"#8E8E93"}, resolved:{label:"Resolved",color:"#34C759"}, closed:{label:"Closed",color:"#636366"} };
const ROLES      = ["admin","agent","viewer"];
const PLANS = {
  free:       { name:"Free",       price:0,   annualPrice:0,    seats:3,   badge:"#636366" },
  pro:        { name:"Pro",        price:99,  annualPrice:990,  seats:10,  badge:"#4F8EF7" },
  business:   { name:"Business",   price:299, annualPrice:2990, seats:25,  badge:"#A855F7" },
  enterprise: { name:"Enterprise", price:999, annualPrice:9990, seats:999, badge:"#FF9500" },
};
const INTEGRATION_META = {
  jira:       { name:"Jira",            icon:"J",  color:"#0052CC", cat:"Engineering", desc:"Sync tickets with Jira issues. Auto-create issues on ticket creation, sync status changes bidirectionally, and link existing Jira issues to tickets.", scope:["Read/write Jira issues","Sync status & priority","Auto-create linked issues","Webhook for real-time updates"], fields:[{key:"baseUrl",label:"Jira Base URL",placeholder:"https://yourcompany.atlassian.net"},{key:"apiKey",label:"API Token",placeholder:"Your Jira API token",secret:true},{key:"project",label:"Default Project Key",placeholder:"ENG"},{key:"syncDirection",label:"Sync Direction",type:"select",options:["Bidirectional","Push only","Pull only"]},{key:"autoCreate",label:"Auto-create Jira issues",type:"toggle"}], steps:["Go to Atlassian → Account Settings → Security → API tokens","Click 'Create API token', name it 'SupportOS'","Copy the token and paste it above","Enter your Jira instance URL and default project key","Click Connect"] },
  linear:     { name:"Linear",          icon:"L",  color:"#5E6AD2", cat:"Engineering", desc:"Link tickets to Linear issues. Push urgent tickets as Linear issues, track engineering progress, and sync resolution status back to tickets.", scope:["Create & link Linear issues","Sync issue status","Assign to Linear team members","Comment sync"], fields:[{key:"apiKey",label:"API Key",placeholder:"lin_api_...",secret:true},{key:"team",label:"Team Name",placeholder:"Engineering"},{key:"syncDirection",label:"Sync Direction",type:"select",options:["Bidirectional","Push only"]},{key:"autoCreate",label:"Auto-create Linear issues",type:"toggle"}], steps:["In Linear, go to Settings → API","Click 'Create Key', name it SupportOS","Copy the key and paste above","Enter your team name exactly as it appears in Linear","Click Connect"] },
  github:     { name:"GitHub",          icon:"⌥",  color:"#C9D1D9", cat:"Engineering", desc:"Create GitHub issues from tickets, reference commits and PRs, and get notified when code changes close customer issues.", scope:["Create issues in repos","Read PR/commit references","Webhook events","Issue status sync"], fields:[{key:"org",label:"Organization or User",placeholder:"myorg"},{key:"repo",label:"Repository",placeholder:"backend"},{key:"webhookSecret",label:"Webhook Secret",placeholder:"Generate a random string",secret:true}], steps:["Go to GitHub → Settings → Developer settings → Personal access tokens","Create token with 'repo' and 'issues' scopes","In your repo, go to Settings → Webhooks → Add webhook","Enter your SupportOS webhook URL and secret","Paste values above and click Connect"] },
  slack:      { name:"Slack",           icon:"⚡", color:"#E01E5A", cat:"Messaging",   desc:"Receive tickets from Slack DMs and channels. Get alert notifications for critical tickets. Allow agents to reply to tickets directly from Slack.", scope:["Read messages from configured channels","Post messages & notifications","Create tickets from DMs","Reply on behalf of agents"], fields:[{key:"botToken",label:"Bot OAuth Token",placeholder:"xoxb-...",secret:true},{key:"channel",label:"Alert Channel",placeholder:"#support-alerts"},{key:"workspace",label:"Workspace Name",placeholder:"Acme HQ"},{key:"notifyOn",label:"Notify on priority",placeholder:"critical,high"},{key:"autoReply",label:"Enable auto-reply DMs",type:"toggle"}], steps:["Go to api.slack.com/apps → Create New App","Choose 'From scratch', name it SupportOS","Under OAuth & Permissions, add Bot Token Scopes: chat:write, im:read, channels:read","Install to your workspace and copy the Bot User OAuth Token","Invite the bot to your alert channel with /invite @SupportOS","Paste the token above and click Connect"] },
  teams:      { name:"Microsoft Teams", icon:"⬡",  color:"#6264A7", cat:"Messaging",   desc:"Integrate with Microsoft Teams to receive tickets from Teams messages, send notifications to channels, and allow agents to manage tickets from Teams.", scope:["Post to Teams channels","Read messages from monitored channels","Send adaptive cards","Create tickets from channel messages"], fields:[{key:"tenant",label:"Tenant Domain",placeholder:"yourcompany.onmicrosoft.com"},{key:"webhookUrl",label:"Incoming Webhook URL",placeholder:"https://yourcompany.webhook.office.com/...",secret:true},{key:"channel",label:"Notification Channel",placeholder:"Support Ops"}], steps:["In Teams, go to the channel → More options → Connectors","Search for 'Incoming Webhook' and click Configure","Name it SupportOS, optionally upload a logo","Copy the webhook URL and paste it above","Enter your tenant domain and click Connect"] },
  whatsapp:   { name:"WhatsApp Business",icon:"◉", color:"#25D366", cat:"Messaging",   desc:"Accept customer tickets via WhatsApp Business API. Auto-reply to common queries, route messages to agents, and send ticket updates back via WhatsApp.", scope:["Receive & send WhatsApp messages","Auto-reply templates","Media attachments","Phone number management"], fields:[{key:"phoneNumber",label:"Business Phone Number",placeholder:"+1 555-000-0000"},{key:"businessId",label:"Business Account ID",placeholder:"Your Meta Business ID",secret:true},{key:"autoReply",label:"Enable auto-reply",type:"toggle"}], steps:["Go to Meta Business Manager → WhatsApp → Getting Started","Create or connect your WhatsApp Business account","Generate a permanent access token with whatsapp_business_messaging permission","Note your Phone Number ID and Business Account ID","Paste values above and click Connect — SupportOS will configure the webhook automatically"] },
  email:      { name:"Email",           icon:"✉",  color:"#4F8EF7", cat:"Messaging",   desc:"Receive customer tickets via email and send replies. Supports auto-threading, attachments, and auto-reply. Works with SendGrid, Mailgun, Postmark, or custom SMTP.", scope:["Receive inbound emails","Send replies with threading","Parse attachments","Auto-reply templates"], fields:[{key:"provider",label:"Email Provider",type:"select",options:["sendgrid","mailgun","postmark","custom"]},{key:"fromAddress",label:"From Address",placeholder:"support@yourcompany.com"},{key:"fromName",label:"From Name",placeholder:"Your Support Team"},{key:"smtpHost",label:"SMTP Host (if custom)",placeholder:"smtp.gmail.com"},{key:"smtpPort",label:"SMTP Port (if custom)",placeholder:"587"},{key:"smtpUser",label:"SMTP Username",placeholder:"support@yourcompany.com"},{key:"smtpPass",label:"SMTP Password",placeholder:"Your SMTP password",secret:true},{key:"autoReply",label:"Enable auto-reply",type:"toggle"}], steps:["Choose your email provider (SendGrid, Mailgun, etc.)","Configure inbound email forwarding to SupportOS webhook","Webhook URL: https://your-domain.com/api/webhooks/email/YOUR_ORG_ID","Set up SMTP credentials for outgoing emails","Configure auto-reply template if desired","Paste credentials above and click Connect"] },
  zoom:       { name:"Zoom",            icon:"Z",  color:"#2D8CFF", cat:"Meetings",    desc:"Start Zoom calls directly from a ticket. Auto-create meetings and send join links to customers. Optionally record calls and attach transcripts to tickets.", scope:["Create & manage meetings","Send meeting invites","Retrieve recordings","Meeting analytics"], fields:[{key:"accountId",label:"Account ID",placeholder:"Your Zoom Account ID"},{key:"clientId",label:"OAuth Client ID",placeholder:"Your app's Client ID"},{key:"clientSecret",label:"OAuth Client Secret",placeholder:"Your app's Client Secret",secret:true},{key:"autoRecord",label:"Auto-record all meetings",type:"toggle"}], steps:["Go to marketplace.zoom.us → Develop → Build App","Choose Server-to-Server OAuth app type","Copy Account ID, Client ID, and Client Secret","Under Scopes, add: meeting:write:admin, recording:read:admin","Paste values above and click Connect"] },
  gcal:       { name:"Google Calendar",  icon:"G",  color:"#EA4335", cat:"Meetings",    desc:"Schedule follow-up calls and meetings from tickets. Sync with agent calendars to check availability and automatically add ticket context to calendar events.", scope:["Read/write calendar events","Check agent availability","Create events with ticket links","Send calendar invites to customers"], fields:[{key:"calendar",label:"Calendar ID",placeholder:"primary or calendar email"},{key:"serviceAccount",label:"Service Account JSON Key",placeholder:'{"type":"service_account",...}',secret:true}], steps:["Go to Google Cloud Console → APIs → Enable Google Calendar API","Go to IAM → Service Accounts → Create Service Account","Grant it the 'Calendar Editor' role","Create and download a JSON key file","Share your Google Calendar with the service account email","Paste the JSON key content above and click Connect"] },
  pagerduty:  { name:"PagerDuty",       icon:"▲",  color:"#06AC38", cat:"Alerting",    desc:"Auto-escalate critical tickets to PagerDuty incidents. On-call teams get paged immediately when SLA-breaching tickets come in.", scope:["Create & manage incidents","Escalation policies","On-call schedules","Incident notes & resolution"], fields:[{key:"routingKey",label:"Routing Key (Integration Key)",placeholder:"Your Events API v2 routing key",secret:true},{key:"minSeverity",label:"Minimum Severity to Alert",type:"select",options:["critical","high","medium"]}], steps:["In PagerDuty, go to Services → Service Directory → New Service","Choose 'Events API v2' as the integration type","Copy the Integration Key (routing key)","Configure your escalation policy","Paste the key above and click Connect"] },
  salesforce:  { name:"Salesforce",     icon:"☁",  color:"#00A1E0", cat:"CRM",         desc:"Pull customer account data, contract values, and open cases from Salesforce. Log ticket resolutions as Salesforce activities. View full customer context inline.", scope:["Read Account & Contact records","Create/update Cases","Log Activities","Query SOQL for customer data"], fields:[{key:"instanceUrl",label:"Instance URL",placeholder:"https://yourcompany.my.salesforce.com"},{key:"username",label:"Salesforce Username",placeholder:"admin@yourcompany.com"},{key:"password",label:"Password + Security Token",placeholder:"password+token",secret:true}], steps:["Log into Salesforce → Setup → Profile → Reset Security Token","Combine your password and security token (no space)","Go to Setup → Connected Apps → New Connected App","Enable OAuth, add relevant scopes (api, refresh_token)","Copy the Consumer Key/Secret — or use username+password auth above","Paste your credentials and click Connect"] },
  zendesk:    { name:"Zendesk",         icon:"☰",  color:"#03363D", cat:"Helpdesk",    desc:"Migrate from or sync with Zendesk. Import historical tickets, sync agent accounts, and maintain a unified view across both platforms during transition.", scope:["Read & write tickets","Sync user/agent profiles","Import ticket history","Webhook bi-sync"], fields:[{key:"subdomain",label:"Zendesk Subdomain",placeholder:"yourcompany"},{key:"adminEmail",label:"Admin Email",placeholder:"admin@yourcompany.com"},{key:"apiToken",label:"API Token",placeholder:"Your Zendesk API token",secret:true}], steps:["In Zendesk, go to Admin Center → Apps & Integrations → Zendesk APIs","Enable Token Access and click Add API Token","Name it SupportOS and copy the token","Enter your subdomain (the part before .zendesk.com)","Paste values above and click Connect"] },
  intercom:   { name:"Intercom",        icon:"◎",  color:"#286EFA", cat:"Helpdesk",    desc:"Sync Intercom conversations to tickets. View full conversation history, user profiles, and company data inline. Respond from SupportOS and have replies appear in Intercom.", scope:["Read & write conversations","Access user & company data","Create notes & tags","Webhook conversation events"], fields:[{key:"appId",label:"App ID",placeholder:"Your Intercom App ID"},{key:"apiKey",label:"Access Token",placeholder:"dG9r...",secret:true}], steps:["In Intercom, go to Settings → Integrations → Developer Hub","Create a new app or use an existing internal app","Go to Authentication → Access Token → Generate","Copy the token and your App ID (found in the URL or Settings → General)","Paste values above and click Connect"] },
};

// ─── Micro Components ─────────────────────────────────────────────────────────
function SlaBar({ pct, sla }) {
  const color = pct > 60 ? "#FF3B30" : pct > 30 ? "#FF9500" : "#34C759";
  const label = sla > 60 ? `${Math.floor(sla/60)}h ${sla%60}m` : `${sla}m`;
  return (
    <div style={{display:"flex",alignItems:"center",gap:6}}>
      <div style={{width:48,height:3,background:"#1E1E2E",borderRadius:2,overflow:"hidden"}}><div style={{width:`${pct}%`,height:"100%",background:color,borderRadius:2}}/></div>
      <span style={{fontSize:10,color,fontFamily:"'DM Mono',monospace"}}>{label}</span>
    </div>
  );
}

function Avatar({ agent, size=28 }) {
  if (!agent) return <div style={{width:size,height:size,borderRadius:"50%",background:"#1E1E2E",border:"1.5px dashed #3A3A4E",display:"flex",alignItems:"center",justifyContent:"center",flexShrink:0}}><span style={{fontSize:size*0.35,color:"#636366"}}>+</span></div>;
  const sc = {online:"#34C759",busy:"#FF3B30",away:"#FF9500",offline:"#636366"}[agent.status||"offline"];
  return (
    <div style={{position:"relative",flexShrink:0}}>
      <div style={{width:size,height:size,borderRadius:"50%",background:"linear-gradient(135deg,#4F8EF7,#A855F7)",display:"flex",alignItems:"center",justifyContent:"center",fontSize:size*0.33,fontWeight:700,color:"#fff",fontFamily:"'DM Mono',monospace"}}>{agent.avatar||"?"}</div>
      <div style={{position:"absolute",bottom:0,right:0,width:size*0.32,height:size*0.32,borderRadius:"50%",background:sc,border:"1.5px solid #0D0D1A"}}/>
    </div>
  );
}

const ChannelBadge = ({ch}) => { const c=CHANNELS[ch]; if(!c) return null; return <span style={{display:"inline-flex",alignItems:"center",gap:3,padding:"2px 7px",borderRadius:4,background:`${c.color}18`,border:`1px solid ${c.color}40`,fontSize:10,color:c.color,fontWeight:600,fontFamily:"'DM Mono',monospace"}}>{c.icon} {c.label}</span>; };
const PriorityDot  = ({p})  => { const d=PRIORITIES[p]; if(!d) return null; return <span style={{display:"inline-flex",alignItems:"center",gap:3,padding:"2px 7px",borderRadius:4,background:d.bg,border:`1px solid ${d.color}40`,fontSize:10,color:d.color,fontWeight:700,fontFamily:"'DM Mono',monospace"}}>● {d.label}</span>; };
const StatusBadge  = ({s})  => { const d=STATUSES[s];   if(!d) return null; return <span style={{display:"inline-flex",alignItems:"center",gap:3,padding:"2px 8px",borderRadius:20,background:`${d.color}15`,border:`1px solid ${d.color}35`,fontSize:10,color:d.color,fontWeight:600}}>{d.label}</span>; };
const Tag          = ({label}) => <span style={{padding:"1px 6px",borderRadius:3,background:"#1E1E2E",border:"1px solid #2D2D3F",fontSize:10,color:"#8E8E93",fontFamily:"'DM Mono',monospace"}}>{label}</span>;
const IntBadge     = ({type,id}) => { const m={jira:{c:"#0052CC",i:"J"},linear:{c:"#5E6AD2",i:"L"}}[type]; if(!m) return null; return <span style={{display:"inline-flex",alignItems:"center",gap:3,padding:"1px 6px",borderRadius:4,background:`${m.c}20`,border:`1px solid ${m.c}50`,fontSize:10,color:m.c,fontWeight:700,fontFamily:"'DM Mono',monospace"}}>{m.i} {id}</span>; };

function Btn({ children, onClick, variant="ghost", size="sm", disabled, style={} }) {
  const base = {padding:size==="lg"?"10px 20px":size==="md"?"8px 16px":"6px 12px",borderRadius:8,fontSize:size==="lg"?13:12,fontWeight:600,cursor:disabled?"not-allowed":"pointer",opacity:disabled?0.5:1,transition:"all 0.15s",border:"none",fontFamily:"inherit",...style};
  const variants = { primary:{background:"linear-gradient(135deg,#4F8EF7,#A855F7)",color:"#fff",boxShadow:"0 4px 14px #4F8EF740"}, ghost:{background:"#141428",border:"1px solid #2D2D3F",color:"#AEAEB2"}, danger:{background:"#FF3B3020",border:"1px solid #FF3B3040",color:"#FF3B30"}, success:{background:"#34C75920",border:"1px solid #34C75940",color:"#34C759"} };
  return <button onClick={!disabled?onClick:undefined} style={{...base,...variants[variant]}}
    onMouseEnter={e=>{if(!disabled&&variant==="ghost"){e.currentTarget.style.borderColor="#4F8EF7";e.currentTarget.style.color="#F2F2F7";}}}
    onMouseLeave={e=>{if(!disabled&&variant==="ghost"){e.currentTarget.style.borderColor="#2D2D3F";e.currentTarget.style.color="#AEAEB2";}}}>{children}</button>;
}

function Modal({ title, onClose, children, width=560 }) {
  useEffect(() => { const h=e=>{if(e.key==="Escape")onClose();}; window.addEventListener("keydown",h); return()=>window.removeEventListener("keydown",h); },[onClose]);
  return (
    <>
      <div onClick={onClose} style={{position:"fixed",inset:0,background:"rgba(0,0,0,0.7)",backdropFilter:"blur(4px)",zIndex:300}}/>
      <div style={{position:"fixed",top:"50%",left:"50%",transform:"translate(-50%,-50%)",width,maxWidth:"95vw",maxHeight:"90vh",background:"#0C0C20",border:"1px solid #2D2D3F",borderRadius:14,zIndex:301,display:"flex",flexDirection:"column",boxShadow:"0 24px 80px rgba(0,0,0,0.8)",animation:"slInUp 0.22s cubic-bezier(0.16,1,0.3,1)"}}>
        <div style={{padding:"18px 22px",borderBottom:"1px solid #1E1E2E",display:"flex",alignItems:"center",justifyContent:"space-between",flexShrink:0}}>
          <span style={{fontSize:15,fontWeight:800,color:"#F2F2F7"}}>{title}</span>
          <button onClick={onClose} style={{background:"none",border:"none",color:"#636366",cursor:"pointer",fontSize:18,lineHeight:1}} onMouseEnter={e=>e.currentTarget.style.color="#FF3B30"} onMouseLeave={e=>e.currentTarget.style.color="#636366"}>✕</button>
        </div>
        <div style={{flex:1,overflow:"auto",padding:"18px 22px"}}>{children}</div>
      </div>
    </>
  );
}

function Field({ label, children, hint }) {
  return (
    <div style={{marginBottom:14}}>
      <label style={{display:"block",fontSize:11,color:"#636366",fontWeight:700,letterSpacing:"0.7px",textTransform:"uppercase",marginBottom:5}}>{label}</label>
      {children}
      {hint && <div style={{fontSize:11,color:"#3A3A4E",marginTop:3}}>{hint}</div>}
    </div>
  );
}

function Input({ value, onChange, placeholder, type="text", style={} }) {
  return <input type={type} value={value} onChange={e=>onChange(e.target.value)} placeholder={placeholder}
    style={{width:"100%",background:"#080818",border:"1px solid #2D2D3F",borderRadius:8,padding:"9px 12px",color:"#AEAEB2",fontSize:13,outline:"none",fontFamily:"inherit",...style}}
    onFocus={e=>e.target.style.borderColor="#4F8EF7"} onBlur={e=>e.target.style.borderColor="#2D2D3F"}/>;
}

function Select({ value, onChange, options, style={} }) {
  return <select value={value} onChange={e=>onChange(e.target.value)}
    style={{width:"100%",background:"#080818",border:"1px solid #2D2D3F",borderRadius:8,padding:"9px 12px",color:"#AEAEB2",fontSize:13,outline:"none",fontFamily:"inherit",cursor:"pointer",...style}}
    onFocus={e=>e.target.style.borderColor="#4F8EF7"} onBlur={e=>e.target.style.borderColor="#2D2D3F"}>
    {options.map(o => typeof o==="string" ? <option key={o} value={o}>{o}</option> : <option key={o.value} value={o.value}>{o.label}</option>)}
  </select>;
}

function Toggle({ value, onChange }) {
  return <div onClick={()=>onChange(!value)} style={{width:38,height:22,borderRadius:11,background:value?"#4F8EF7":"#1E1E2E",border:`1px solid ${value?"#4F8EF7":"#2D2D3F"}`,display:"flex",alignItems:"center",padding:"0 3px",cursor:"pointer",transition:"all 0.2s"}}>
    <div style={{width:16,height:16,borderRadius:"50%",background:"#fff",transform:value?"translateX(16px)":"translateX(0)",transition:"transform 0.2s"}}/>
  </div>;
}

// ─── Login Screen ─────────────────────────────────────────────────────────────
function LoginScreen({ onAuth }) {
  const [mode, setMode] = useState("login");
  const [email, setEmail] = useState("admin@acme.com");
  const [password, setPassword] = useState("password");
  const [name, setName] = useState("");
  const [orgName, setOrgName] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  async function submit() {
    setLoading(true); setError("");
    try {
      const endpoint = mode==="login" ? "/api/auth/login" : "/api/auth/signup";
      const body = mode==="login" ? {email,password} : {email,password,name,orgName};
      const res = await fetch(`http://localhost:3001${endpoint}`, { method:"POST", headers:{"Content-Type":"application/json"}, body:JSON.stringify(body) });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error||"Failed");
      onAuth(data.token, data.user, data.orgs);
    } catch(e) { setError(e.message); }
    setLoading(false);
  }

  const demoAccounts = [
    { email:"admin@acme.com", label:"Acme Admin", role:"Admin · Enterprise" },
    { email:"marcus@acme.com", label:"Marcus Webb", role:"Agent · Acme" },
    { email:"admin@beta.com", label:"Beta Admin", role:"Admin · Beta Labs" },
  ];

  return (
    <div style={{minHeight:"100vh",background:"#07070F",display:"flex",alignItems:"center",justifyContent:"center",fontFamily:"'DM Sans',-apple-system,sans-serif"}}>
      <style>{`@import url('https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700;800&family=DM+Mono:wght@400;500;700&display=swap'); *{box-sizing:border-box;margin:0;padding:0} @keyframes slInUp{from{opacity:0;transform:translateY(16px)}to{opacity:1;transform:translateY(0)}} @keyframes fdIn{from{opacity:0}to{opacity:1}}`}</style>
      <div style={{width:420,animation:"slInUp 0.3s ease"}}>
        <div style={{textAlign:"center",marginBottom:32}}>
          <div style={{width:48,height:48,borderRadius:14,background:"linear-gradient(135deg,#4F8EF7,#A855F7)",display:"flex",alignItems:"center",justifyContent:"center",fontSize:24,fontWeight:900,color:"#fff",margin:"0 auto 12px"}}>S</div>
          <div style={{fontSize:22,fontWeight:800,color:"#F2F2F7",letterSpacing:"-0.3px"}}>SupportOS</div>
          <div style={{fontSize:12,color:"#636366",marginTop:2,letterSpacing:"0.5px"}}>MISSION CONTROL</div>
        </div>
        <div style={{background:"#0A0A1A",border:"1px solid #1E1E2E",borderRadius:14,padding:28}}>
          <div style={{display:"flex",gap:0,marginBottom:24,background:"#07070F",borderRadius:8,padding:3,border:"1px solid #1E1E2E"}}>
            {["login","signup"].map(m=>(
              <button key={m} onClick={()=>{setMode(m);setError("");}} style={{flex:1,padding:"7px",borderRadius:6,background:mode===m?"#1A1A2E":"none",border:`1px solid ${mode===m?"#2D2D3F":"transparent"}`,color:mode===m?"#F2F2F7":"#636366",fontSize:13,fontWeight:mode===m?700:500,cursor:"pointer",transition:"all 0.15s",fontFamily:"inherit"}}>
                {m==="login"?"Sign In":"Create Account"}
              </button>
            ))}
          </div>
          {mode==="signup" && <>
            <Field label="Full Name"><Input value={name} onChange={setName} placeholder="Jane Smith"/></Field>
            <Field label="Company / Org Name"><Input value={orgName} onChange={setOrgName} placeholder="Acme Corp"/></Field>
          </>}
          <Field label="Email"><Input value={email} onChange={setEmail} placeholder="you@company.com" type="email"/></Field>
          <Field label="Password"><Input value={password} onChange={setPassword} placeholder="••••••••" type="password"/></Field>
          {error && <div style={{padding:"8px 12px",background:"#FF3B3015",border:"1px solid #FF3B3040",borderRadius:7,color:"#FF3B30",fontSize:12,marginBottom:14}}>{error}</div>}
          <Btn variant="primary" size="lg" onClick={submit} disabled={loading} style={{width:"100%",marginTop:4}}>{loading?"Signing in…":mode==="login"?"Sign In →":"Create Account →"}</Btn>
        </div>
        {mode==="login" && (
          <div style={{marginTop:16}}>
            <div style={{fontSize:11,color:"#636366",textAlign:"center",marginBottom:8,letterSpacing:"0.5px"}}>DEMO ACCOUNTS (password: "password")</div>
            <div style={{display:"flex",flexDirection:"column",gap:6}}>
              {demoAccounts.map(a=>(
                <button key={a.email} onClick={()=>{setEmail(a.email);setPassword("password");}} style={{padding:"8px 12px",background:"#0A0A1A",border:"1px solid #1E1E2E",borderRadius:8,cursor:"pointer",display:"flex",justifyContent:"space-between",alignItems:"center",transition:"border-color 0.15s",fontFamily:"inherit"}} onMouseEnter={e=>e.currentTarget.style.borderColor="#4F8EF7"} onMouseLeave={e=>e.currentTarget.style.borderColor="#1E1E2E"}>
                  <span style={{fontSize:12,color:"#AEAEB2",fontWeight:600}}>{a.label}</span>
                  <span style={{fontSize:10,color:"#636366"}}>{a.role}</span>
                </button>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

// ─── New Ticket Modal ─────────────────────────────────────────────────────────
function NewTicketModal({ onClose, onCreated, agents }) {
  const api = useApi(); const toast = useToast();
  const [form, setForm] = useState({ title:"", channel:"email", priority:"medium", assigneeId:"", customer:"", customerEmail:"", tags:"", description:"", customFields:{ productArea:"", severity:"P3", tier:"", contractValue:"" } });
  const [loading, setLoading] = useState(false);
  const set = (k,v) => setForm(f=>({...f,[k]:v}));
  const setCF = (k,v) => setForm(f=>({...f,customFields:{...f.customFields,[k]:v}}));

  async function submit() {
    if (!form.title.trim()) return toast("Title is required","error");
    setLoading(true);
    try {
      const data = await api.post("/tickets", { ...form, tags: form.tags.split(",").map(t=>t.trim()).filter(Boolean) });
      toast("Ticket created: "+data.ticket.id,"success");
      onCreated(data.ticket);
      onClose();
    } catch(e) { toast(e.message,"error"); }
    setLoading(false);
  }

  return (
    <Modal title="Create New Ticket" onClose={onClose} width={680}>
      <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:14}}>
        <div style={{gridColumn:"1/-1"}}>
          <Field label="Subject / Title *"><Input value={form.title} onChange={v=>set("title",v)} placeholder="Describe the issue briefly"/></Field>
        </div>
        <Field label="Channel *"><Select value={form.channel} onChange={v=>set("channel",v)} options={Object.entries(CHANNELS).map(([k,v])=>({value:k,label:`${v.icon} ${v.label}`}))}/></Field>
        <Field label="Priority *"><Select value={form.priority} onChange={v=>set("priority",v)} options={Object.entries(PRIORITIES).map(([k,v])=>({value:k,label:`● ${v.label}`}))}/></Field>
        <Field label="Customer Name"><Input value={form.customer} onChange={v=>set("customer",v)} placeholder="Acme Inc."/></Field>
        <Field label="Customer Email"><Input value={form.customerEmail} onChange={v=>set("customerEmail",v)} placeholder="contact@customer.com" type="email"/></Field>
        <Field label="Assign To"><Select value={form.assigneeId} onChange={v=>set("assigneeId",v)} options={[{value:"",label:"Unassigned"},...agents.map(a=>({value:a.id,label:`${a.name} (${a.role})`}))]}/></Field>
        <Field label="Tags"><Input value={form.tags} onChange={v=>set("tags",v)} placeholder="backend, api, urgent (comma-separated)"/></Field>
        <div style={{gridColumn:"1/-1"}}>
          <Field label="Initial Message / Description">
            <textarea value={form.description} onChange={e=>set("description",e.target.value)} placeholder="Describe the issue in detail, steps to reproduce, impact…" rows={4}
              style={{width:"100%",background:"#080818",border:"1px solid #2D2D3F",borderRadius:8,padding:"9px 12px",color:"#AEAEB2",fontSize:13,outline:"none",fontFamily:"inherit",resize:"vertical"}}
              onFocus={e=>e.target.style.borderColor="#4F8EF7"} onBlur={e=>e.target.style.borderColor="#2D2D3F"}/>
          </Field>
        </div>
        <div style={{gridColumn:"1/-1",padding:"12px 14px",background:"#080818",borderRadius:8,border:"1px solid #1E1E2E"}}>
          <div style={{fontSize:11,color:"#636366",fontWeight:700,letterSpacing:"0.7px",textTransform:"uppercase",marginBottom:10}}>Custom Fields</div>
          <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:10}}>
            {[["productArea","Product Area","Platform Core"],["severity","Severity","P1, P2, P3"],["tier","Customer Tier","Enterprise, Business"],["contractValue","Contract Value","$240,000/yr"]].map(([k,label,ph])=>(
              <Field key={k} label={label}><Input value={form.customFields[k]} onChange={v=>setCF(k,v)} placeholder={ph}/></Field>
            ))}
          </div>
        </div>
      </div>
      <div style={{display:"flex",justifyContent:"flex-end",gap:8,marginTop:18,paddingTop:14,borderTop:"1px solid #1E1E2E"}}>
        <Btn onClick={onClose}>Cancel</Btn>
        <Btn variant="primary" onClick={submit} disabled={loading}>{loading?"Creating…":"Create Ticket"}</Btn>
      </div>
    </Modal>
  );
}

// ─── Assign Modal ─────────────────────────────────────────────────────────────
function AssignModal({ ticket, agents, onClose, onAssigned }) {
  const api = useApi(); const toast = useToast();
  const [selectedId, setSelectedId] = useState(ticket.assigneeId||"");
  const [loading, setLoading] = useState(false);
  async function save() {
    setLoading(true);
    try {
      const data = await api.patch(`/tickets/${ticket.id}`, { assigneeId: selectedId||null });
      toast("Assignee updated","success"); onAssigned(data.ticket); onClose();
    } catch(e) { toast(e.message,"error"); }
    setLoading(false);
  }
  return (
    <Modal title="Assign Ticket" onClose={onClose} width={380}>
      <div style={{display:"flex",flexDirection:"column",gap:6,marginBottom:18}}>
        <div onClick={()=>setSelectedId("")} style={{display:"flex",alignItems:"center",gap:10,padding:"10px 12px",borderRadius:8,border:`1px solid ${!selectedId?"#4F8EF7":"#1E1E2E"}`,background:!selectedId?"#4F8EF715":"#080818",cursor:"pointer"}}>
          <div style={{width:32,height:32,borderRadius:"50%",background:"#1E1E2E",border:"1.5px dashed #3A3A4E",display:"flex",alignItems:"center",justifyContent:"center",fontSize:14,color:"#636366"}}>?</div>
          <span style={{fontSize:13,color:!selectedId?"#4F8EF7":"#636366",fontWeight:!selectedId?700:400}}>Unassigned</span>
        </div>
        {agents.map(a=>(
          <div key={a.id} onClick={()=>setSelectedId(a.id)} style={{display:"flex",alignItems:"center",gap:10,padding:"10px 12px",borderRadius:8,border:`1px solid ${selectedId===a.id?"#4F8EF7":"#1E1E2E"}`,background:selectedId===a.id?"#4F8EF715":"#080818",cursor:"pointer"}}>
            <Avatar agent={a} size={32}/>
            <div><div style={{fontSize:13,color:selectedId===a.id?"#4F8EF7":"#AEAEB2",fontWeight:selectedId===a.id?700:500}}>{a.name}</div><div style={{fontSize:10,color:"#636366"}}>{a.role} · {a.tickets||0} open tickets</div></div>
            {selectedId===a.id && <span style={{marginLeft:"auto",color:"#4F8EF7",fontSize:16}}>✓</span>}
          </div>
        ))}
      </div>
      <div style={{display:"flex",justifyContent:"flex-end",gap:8}}>
        <Btn onClick={onClose}>Cancel</Btn>
        <Btn variant="primary" onClick={save} disabled={loading}>{loading?"Saving…":"Assign"}</Btn>
      </div>
    </Modal>
  );
}

// ─── Status Modal ─────────────────────────────────────────────────────────────
function StatusModal({ ticket, onClose, onUpdated }) {
  const api = useApi(); const toast = useToast();
  const [status, setStatus] = useState(ticket.status);
  const [loading, setLoading] = useState(false);
  async function save() {
    setLoading(true);
    try { const d = await api.patch(`/tickets/${ticket.id}`,{status}); toast("Status updated","success"); onUpdated(d.ticket); onClose(); }
    catch(e) { toast(e.message,"error"); }
    setLoading(false);
  }
  return (
    <Modal title="Update Status" onClose={onClose} width={360}>
      <div style={{display:"flex",flexDirection:"column",gap:6,marginBottom:18}}>
        {Object.entries(STATUSES).map(([k,s])=>(
          <div key={k} onClick={()=>setStatus(k)} style={{display:"flex",alignItems:"center",gap:10,padding:"10px 14px",borderRadius:8,border:`1px solid ${status===k?s.color:"#1E1E2E"}`,background:status===k?`${s.color}15`:"#080818",cursor:"pointer",transition:"all 0.15s"}}>
            <div style={{width:8,height:8,borderRadius:"50%",background:s.color}}/>
            <span style={{fontSize:13,color:status===k?s.color:"#AEAEB2",fontWeight:status===k?700:500}}>{s.label}</span>
            {status===k&&<span style={{marginLeft:"auto",color:s.color}}>✓</span>}
          </div>
        ))}
      </div>
      <div style={{display:"flex",justifyContent:"flex-end",gap:8}}>
        <Btn onClick={onClose}>Cancel</Btn>
        <Btn variant="primary" onClick={save} disabled={loading}>{loading?"Saving…":"Update Status"}</Btn>
      </div>
    </Modal>
  );
}

// ─── Integration Modal ────────────────────────────────────────────────────────
function IntegrationModal({ intId, currentConfig, isConnected, onClose, onSave }) {
  const meta = INTEGRATION_META[intId];
  const api = useApi(); const toast = useToast();
  const [tab, setTab] = useState("setup");
  const [form, setForm] = useState(() => {
    const init = {};
    (meta?.fields||[]).forEach(f => { init[f.key] = currentConfig?.[f.key] || (f.type==="toggle"?false:""); });
    return init;
  });
  const [loading, setLoading] = useState(false);

  async function connect() {
    setLoading(true);
    try {
      await api.post(`/integrations/${intId}/connect`, { config: form });
      toast(`${meta.name} connected!`, "success");
      onSave();
    } catch(e) { toast(e.message, "error"); }
    setLoading(false);
  }

  async function disconnect() {
    if (!window.confirm(`Disconnect ${meta.name}? This will stop all syncing immediately.`)) return;
    setLoading(true);
    try {
      await api.del(`/integrations/${intId}/disconnect`);
      toast(`${meta.name} disconnected`, "info");
      onSave();
    } catch(e) { toast(e.message, "error"); }
    setLoading(false);
  }

  if (!meta) return null;
  return (
    <Modal title="" onClose={onClose} width={640}>
      {/* Header */}
      <div style={{display:"flex",alignItems:"center",gap:14,marginBottom:20,paddingBottom:16,borderBottom:"1px solid #1E1E2E"}}>
        <div style={{width:44,height:44,borderRadius:11,background:`${meta.color}22`,border:`1px solid ${meta.color}40`,display:"flex",alignItems:"center",justifyContent:"center",fontSize:20,color:meta.color,fontWeight:900}}>{meta.icon}</div>
        <div>
          <div style={{fontSize:17,fontWeight:800,color:"#F2F2F7"}}>{meta.name}</div>
          <div style={{fontSize:12,color:isConnected?"#34C759":"#636366"}}>{isConnected?"● Connected & Active":"○ Not connected"}</div>
        </div>
        {isConnected && <Btn variant="danger" onClick={disconnect} style={{marginLeft:"auto"}} disabled={loading}>Disconnect</Btn>}
      </div>

      {/* Description & Scope */}
      <div style={{padding:"12px 14px",background:"#080818",borderRadius:8,border:"1px solid #1E1E2E",marginBottom:16}}>
        <p style={{fontSize:13,color:"#AEAEB2",lineHeight:1.6,marginBottom:10}}>{meta.desc}</p>
        <div style={{fontSize:11,color:"#636366",fontWeight:700,letterSpacing:"0.7px",marginBottom:6}}>PERMISSIONS & SCOPE</div>
        <div style={{display:"flex",flexWrap:"wrap",gap:5}}>
          {meta.scope.map(s=><span key={s} style={{padding:"2px 8px",background:"#4F8EF715",border:"1px solid #4F8EF730",borderRadius:4,fontSize:11,color:"#4F8EF7"}}>{s}</span>)}
        </div>
      </div>

      {/* Tabs */}
      <div style={{display:"flex",gap:2,marginBottom:16,background:"#080818",borderRadius:8,padding:3,border:"1px solid #1E1E2E"}}>
        {["setup","steps"].map(t=><button key={t} onClick={()=>setTab(t)} style={{flex:1,padding:"6px",borderRadius:6,background:tab===t?"#1A1A2E":"none",border:`1px solid ${tab===t?"#2D2D3F":"transparent"}`,color:tab===t?"#F2F2F7":"#636366",fontSize:12,fontWeight:tab===t?700:500,cursor:"pointer",fontFamily:"inherit"}}>{t==="setup"?`${isConnected?"Update":"Configure"} Integration`:"Connection Steps"}</button>)}
      </div>

      {tab==="steps" && (
        <div style={{display:"flex",flexDirection:"column",gap:10}}>
          {meta.steps.map((step,i)=>(
            <div key={i} style={{display:"flex",gap:12,alignItems:"flex-start"}}>
              <div style={{width:24,height:24,borderRadius:"50%",background:`${meta.color}20`,border:`1px solid ${meta.color}50`,display:"flex",alignItems:"center",justifyContent:"center",fontSize:11,fontWeight:800,color:meta.color,flexShrink:0}}>{i+1}</div>
              <p style={{fontSize:13,color:"#AEAEB2",lineHeight:1.5,paddingTop:3}}>{step}</p>
            </div>
          ))}
          <Btn onClick={()=>setTab("setup")} style={{marginTop:8,alignSelf:"flex-start"}}>Go to Configuration →</Btn>
        </div>
      )}

      {tab==="setup" && (
        <>
          <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:12}}>
            {(meta.fields||[]).map(f=>(
              <Field key={f.key} label={f.label}>
                {f.type==="toggle" ? <div style={{display:"flex",alignItems:"center",gap:8}}><Toggle value={!!form[f.key]} onChange={v=>setForm(x=>({...x,[f.key]:v}))}/><span style={{fontSize:12,color:"#636366"}}>{form[f.key]?"Enabled":"Disabled"}</span></div>
                : f.type==="select" ? <Select value={form[f.key]} onChange={v=>setForm(x=>({...x,[f.key]:v}))} options={f.options}/>
                : <Input value={form[f.key]||""} onChange={v=>setForm(x=>({...x,[f.key]:v}))} placeholder={f.placeholder} type={f.secret?"password":"text"}/>}
              </Field>
            ))}
          </div>
          <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginTop:18,paddingTop:14,borderTop:"1px solid #1E1E2E"}}>
            <button onClick={()=>setTab("steps")} style={{background:"none",border:"none",color:"#636366",cursor:"pointer",fontSize:12}}>View setup steps ↗</button>
            <div style={{display:"flex",gap:8}}>
              <Btn onClick={onClose}>Cancel</Btn>
              <Btn variant="primary" onClick={connect} disabled={loading}>{loading?"Connecting…":isConnected?"Update":"Connect"}</Btn>
            </div>
          </div>
        </>
      )}
    </Modal>
  );
}

// ─── Invite Member Modal ──────────────────────────────────────────────────────
function InviteModal({ onClose, onInvited }) {
  const api = useApi(); const toast = useToast();
  const [email, setEmail] = useState(""); const [role, setRole] = useState("agent"); const [loading, setLoading] = useState(false); const [result, setResult] = useState(null);
  async function submit() {
    if (!email.trim()) return toast("Email required","error");
    setLoading(true);
    try { const d = await api.post("/team/invite",{email,role}); setResult(d); toast("Invite sent!","success"); onInvited(); }
    catch(e) { toast(e.message,"error"); }
    setLoading(false);
  }
  return (
    <Modal title="Invite Team Member" onClose={onClose} width={460}>
      {result ? (
        <div style={{textAlign:"center",padding:"20px 0"}}>
          <div style={{fontSize:32,marginBottom:12}}>🎉</div>
          <div style={{fontSize:15,fontWeight:700,color:"#F2F2F7",marginBottom:6}}>Invite sent to {result.invite.email}</div>
          <div style={{fontSize:12,color:"#636366",marginBottom:16}}>They'll receive an email with a link to join your workspace.</div>
          <div style={{padding:"10px 14px",background:"#080818",border:"1px solid #1E1E2E",borderRadius:8,fontFamily:"'DM Mono',monospace",fontSize:11,color:"#4F8EF7",wordBreak:"break-all",marginBottom:16}}>{result.inviteUrl}</div>
          <Btn variant="primary" onClick={onClose}>Done</Btn>
        </div>
      ) : <>
        <Field label="Email Address"><Input value={email} onChange={setEmail} placeholder="colleague@company.com" type="email"/></Field>
        <Field label="Role">
          <div style={{display:"flex",flexDirection:"column",gap:6}}>
            {[{r:"admin",desc:"Full access — manage team, billing, settings"},{r:"agent",desc:"Handle tickets, view reports"},{r:"viewer",desc:"Read-only access to tickets and reports"}].map(({r,desc})=>(
              <div key={r} onClick={()=>setRole(r)} style={{display:"flex",alignItems:"center",gap:10,padding:"10px 12px",borderRadius:8,border:`1px solid ${role===r?"#4F8EF7":"#1E1E2E"}`,background:role===r?"#4F8EF715":"#080818",cursor:"pointer"}}>
                <div style={{flex:1}}><div style={{fontSize:13,color:role===r?"#4F8EF7":"#AEAEB2",fontWeight:role===r?700:500,textTransform:"capitalize"}}>{r}</div><div style={{fontSize:11,color:"#636366"}}>{desc}</div></div>
                {role===r&&<span style={{color:"#4F8EF7"}}>✓</span>}
              </div>
            ))}
          </div>
        </Field>
        <div style={{display:"flex",justifyContent:"flex-end",gap:8,marginTop:18}}>
          <Btn onClick={onClose}>Cancel</Btn>
          <Btn variant="primary" onClick={submit} disabled={loading}>{loading?"Sending…":"Send Invite"}</Btn>
        </div>
      </>}
    </Modal>
  );
}

// ─── Floating Ticket Pane ─────────────────────────────────────────────────────
function FloatingTicketPane({ ticketId, agents, onClose, onUpdated }) {
  const api = useApi(); const toast = useToast();
  const [ticket, setTicket] = useState(null);
  const [messages, setMessages] = useState([]);
  const [attachments, setAttachments] = useState([]);
  const [detailOpen, setDetailOpen] = useState(true);
  const [tab, setTab] = useState("conversation");
  const [replyText, setReplyText] = useState("");
  const [replyType, setReplyType] = useState("agent");
  const [sending, setSending] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [modal, setModal] = useState(null);
  const fileRef = useRef(null);

  const load = useCallback(async () => {
    try { const d = await api.get(`/tickets/${ticketId}`); setTicket(d.ticket); setMessages(d.messages||[]); setAttachments(d.attachments||[]); }
    catch(e) { toast(e.message,"error"); onClose(); }
  }, [ticketId]);

  useEffect(() => { load(); }, [load]);
  useEffect(() => { const h=e=>{if(e.key==="Escape")onClose();}; window.addEventListener("keydown",h); return()=>window.removeEventListener("keydown",h); }, [onClose]);

  async function sendReply() {
    if (!replyText.trim()) return;
    setSending(true);
    try {
      const d = await api.post(`/tickets/${ticketId}/messages`, { body: replyText.trim(), type: replyType });
      setMessages(m=>[...m, d.message]); setReplyText("");
      if (replyType==="agent") { const td = await api.patch(`/tickets/${ticketId}`,{status:ticket.status==="open"?"pending":ticket.status}); setTicket(td.ticket); onUpdated(td.ticket); }
      toast("Reply sent","success");
    } catch(e) { toast(e.message,"error"); }
    setSending(false);
  }

  async function handleFiles(files) {
    if (!files.length) return;
    setUploading(true);
    const fd = new FormData();
    Array.from(files).forEach(f => fd.append("files", f));
    try { const d = await api.upload(`/tickets/${ticketId}/attachments`, fd); setAttachments(a=>[...a,...d.attachments]); toast(`${d.attachments.length} file(s) uploaded`,"success"); }
    catch(e) { toast(e.message,"error"); }
    setUploading(false);
  }

  async function updateField(field, value) {
    try { const d = await api.patch(`/tickets/${ticketId}`,{[field]:value}); setTicket(d.ticket); onUpdated(d.ticket); toast("Updated","success"); }
    catch(e) { toast(e.message,"error"); }
  }

  async function deleteAttachment(attId) {
    try { await api.del(`/tickets/${ticketId}/attachments/${attId}`); setAttachments(a=>a.filter(x=>x.id!==attId)); toast("Attachment removed","info"); }
    catch(e) { toast(e.message,"error"); }
  }

  if (!ticket) return (
    <>
      <div onClick={onClose} style={{position:"fixed",inset:0,background:"rgba(0,0,0,0.7)",backdropFilter:"blur(4px)",zIndex:200}}/>
      <div style={{position:"fixed",top:0,right:0,bottom:0,width:"80%",background:"#09091C",zIndex:201,display:"flex",alignItems:"center",justifyContent:"center"}}>
        <div style={{color:"#636366",fontSize:13}}>Loading…</div>
      </div>
    </>
  );

  const slaColor = ticket.slaPct>60?"#FF3B30":ticket.slaPct>30?"#FF9500":"#34C759";
  const TABS = ["conversation","details","attachments","activity","integrations"];

  return (
    <>
      <div onClick={onClose} style={{position:"fixed",inset:0,background:"rgba(0,0,0,0.7)",backdropFilter:"blur(4px)",zIndex:200,animation:"fdIn 0.2s ease"}}/>
      <div style={{position:"fixed",top:0,right:0,bottom:0,width:"80%",background:"#09091C",zIndex:201,display:"flex",boxShadow:"-24px 0 80px rgba(0,0,0,0.8)",animation:"slIn 0.3s cubic-bezier(0.16,1,0.3,1)"}}>

        {/* Thread */}
        <div style={{flex:1,display:"flex",flexDirection:"column",borderRight:"1px solid #1A1A2E",overflow:"hidden",minWidth:0}}>
          {/* Header */}
          <div style={{padding:"16px 22px",borderBottom:"1px solid #1A1A2E",background:"#0A0A1A",flexShrink:0}}>
            <div style={{display:"flex",alignItems:"flex-start",justifyContent:"space-between",gap:12}}>
              <div style={{flex:1,minWidth:0}}>
                <div style={{display:"flex",alignItems:"center",gap:7,marginBottom:6,flexWrap:"wrap"}}>
                  <span style={{fontSize:11,color:"#4F8EF7",fontFamily:"'DM Mono',monospace",fontWeight:700}}>{ticket.id}</span>
                  <StatusBadge s={ticket.status}/>
                  <PriorityDot p={ticket.priority}/>
                  <ChannelBadge ch={ticket.channel}/>
                </div>
                <h2 style={{fontSize:17,fontWeight:800,color:"#F2F2F7",lineHeight:1.3,marginBottom:5}}>{ticket.title}</h2>
                <div style={{fontSize:12,color:"#636366"}}>{ticket.customer} · {ticket.customerEmail}</div>
              </div>
              <div style={{display:"flex",gap:6,flexShrink:0,flexWrap:"wrap",justifyContent:"flex-end"}}>
                <Btn size="sm" onClick={()=>setModal("assign")}>Assign</Btn>
                <Btn size="sm" onClick={()=>setModal("status")}>Status</Btn>
                <Btn size="sm" onClick={()=>updateField("priority", ticket.priority==="critical"?"high":ticket.priority==="high"?"medium":ticket.priority==="medium"?"low":"critical")}>Priority</Btn>
                <Btn size="sm" onClick={()=>{if(window.confirm("Escalate to Critical?"))updateField("priority","critical");}}>Escalate</Btn>
                <button onClick={()=>setDetailOpen(o=>!o)} style={{padding:"6px 10px",background:"#141428",border:"1px solid #2D2D3F",borderRadius:7,color:"#636366",fontSize:13,cursor:"pointer"}}>{detailOpen?"⇥":"⇤"}</button>
                <button onClick={onClose} style={{padding:"6px 10px",background:"#141428",border:"1px solid #2D2D3F",borderRadius:7,color:"#636366",fontSize:16,cursor:"pointer",lineHeight:1}}
                  onMouseEnter={e=>e.currentTarget.style.color="#FF3B30"} onMouseLeave={e=>e.currentTarget.style.color="#636366"}>✕</button>
              </div>
            </div>
          </div>

          {/* SLA Banner */}
          {ticket.slaPct>0&&<div style={{padding:"6px 22px",background:`${slaColor}08`,borderBottom:`1px solid ${slaColor}25`,display:"flex",alignItems:"center",gap:12,flexShrink:0}}>
            <span style={{fontSize:9,fontWeight:800,color:slaColor,letterSpacing:"1px"}}>SLA</span>
            <SlaBar pct={ticket.slaPct} sla={ticket.sla}/>
            <span style={{fontSize:11,color:"#636366"}}>{ticket.slaPct>60?"⚠ Breach imminent":ticket.slaPct>30?"In progress":"On track"}</span>
          </div>}

          {/* Tabs */}
          <div style={{display:"flex",borderBottom:"1px solid #1A1A2E",flexShrink:0,background:"#0A0A1A",overflowX:"auto"}}>
            {TABS.map(t=><button key={t} onClick={()=>setTab(t)} style={{padding:"10px 18px",background:"none",border:"none",borderBottom:`2px solid ${tab===t?"#4F8EF7":"transparent"}`,color:tab===t?"#4F8EF7":"#636366",fontSize:12,cursor:"pointer",fontWeight:tab===t?700:500,whiteSpace:"nowrap",fontFamily:"inherit"}}>
              {t.charAt(0).toUpperCase()+t.slice(1)}{t==="attachments"&&attachments.length>0?` (${attachments.length})`:""}
            </button>)}
          </div>

          {/* Tab Content */}
          <div style={{flex:1,overflow:"auto"}}>
            {/* Conversation */}
            {tab==="conversation"&&<div style={{padding:"18px 22px"}}>
              {messages.filter(m=>m.type!=="internal").length===0 && <div style={{color:"#3A3A4E",fontSize:13,textAlign:"center",padding:"40px 0"}}>No messages yet</div>}
              {messages.map((m,i)=>(
                <div key={m.id||i} style={{marginBottom:18,display:"flex",flexDirection:"column",alignItems:m.type==="agent"?"flex-end":"flex-start"}}>
                  {m.type!=="internal"&&<>
                    <span style={{fontSize:10,color:"#636366",marginBottom:4}}>{m.authorName} · {new Date(m.createdAt).toLocaleTimeString([],{hour:"2-digit",minute:"2-digit"})}</span>
                    <div style={{maxWidth:"76%",padding:"11px 15px",borderRadius:12,background:m.type==="agent"?"#172040":"#141428",border:`1px solid ${m.type==="agent"?"#4F8EF728":"#2D2D3F"}`,fontSize:13,color:"#C7C7CC",lineHeight:1.55}}>{m.body}</div>
                  </>}
                  {m.type==="internal"&&<div style={{width:"100%",margin:"8px 0",padding:"10px 14px",background:"#1A1400",border:"1px solid #FF950030",borderRadius:8,borderLeft:"3px solid #FF9500"}}>
                    <div style={{fontSize:10,color:"#FF9500",fontWeight:700,marginBottom:4}}>🔒 INTERNAL · {m.authorName} · {new Date(m.createdAt).toLocaleTimeString([],{hour:"2-digit",minute:"2-digit"})}</div>
                    <div style={{fontSize:12.5,color:"#8E8E93",lineHeight:1.5}}>{m.body}</div>
                  </div>}
                </div>
              ))}
            </div>}

            {/* Details */}
            {tab==="details"&&<div style={{padding:"18px 22px"}}>
              <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:10,marginBottom:14}}>
                {Object.entries(ticket.customFields||{}).map(([k,v])=>(
                  <div key={k} style={{background:"#0D0D1E",border:"1px solid #1A1A2E",borderRadius:8,padding:"10px 12px"}}>
                    <div style={{fontSize:10,color:"#636366",fontWeight:700,letterSpacing:"0.7px",textTransform:"uppercase",marginBottom:3}}>{k.replace(/([A-Z])/g," $1").trim()}</div>
                    <div style={{fontSize:13,color:"#E5E5EA",fontWeight:500}}>{v||"—"}</div>
                  </div>
                ))}
              </div>
              <div style={{background:"#0D0D1E",border:"1px solid #1A1A2E",borderRadius:8,padding:12,marginBottom:10}}>
                <div style={{fontSize:10,color:"#636366",fontWeight:700,letterSpacing:"0.7px",textTransform:"uppercase",marginBottom:7}}>Tags</div>
                <div style={{display:"flex",gap:5,flexWrap:"wrap"}}>{(ticket.tags||[]).map(t=><Tag key={t} label={t}/>)}</div>
              </div>
              <div style={{background:"#0D0D1E",border:"1px solid #1A1A2E",borderRadius:8,padding:12}}>
                <div style={{fontSize:10,color:"#636366",fontWeight:700,letterSpacing:"0.7px",textTransform:"uppercase",marginBottom:7}}>Linked Issues</div>
                <div style={{display:"flex",gap:8,alignItems:"center"}}>
                  {ticket.jira&&<IntBadge type="jira" id={ticket.jira}/>}
                  {ticket.linear&&<IntBadge type="linear" id={ticket.linear}/>}
                  {!ticket.jira&&!ticket.linear&&<span style={{fontSize:12,color:"#636366"}}>None linked</span>}
                </div>
              </div>
            </div>}

            {/* Attachments */}
            {tab==="attachments"&&<div style={{padding:"18px 22px"}}>
              <div onClick={()=>fileRef.current?.click()} style={{border:"2px dashed #2D2D3F",borderRadius:10,padding:"24px",textAlign:"center",cursor:"pointer",marginBottom:16,transition:"border-color 0.15s"}}
                onMouseEnter={e=>e.currentTarget.style.borderColor="#4F8EF7"} onMouseLeave={e=>e.currentTarget.style.borderColor="#2D2D3F"}
                onDragOver={e=>{e.preventDefault();e.currentTarget.style.borderColor="#4F8EF7";}} onDrop={e=>{e.preventDefault();handleFiles(e.dataTransfer.files);}}>
                <div style={{fontSize:24,marginBottom:8}}>📎</div>
                <div style={{fontSize:13,color:"#636366"}}>{uploading?"Uploading…":"Drop files here or click to browse"}</div>
                <div style={{fontSize:11,color:"#3A3A4E",marginTop:4}}>Max 20MB per file</div>
              </div>
              <input ref={fileRef} type="file" multiple style={{display:"none"}} onChange={e=>handleFiles(e.target.files)}/>
              {attachments.length===0&&<div style={{color:"#3A3A4E",fontSize:13,textAlign:"center",padding:"20px 0"}}>No attachments yet</div>}
              {attachments.map(a=>(
                <div key={a.id} style={{display:"flex",alignItems:"center",gap:10,padding:"10px 12px",background:"#0D0D1E",border:"1px solid #1A1A2E",borderRadius:8,marginBottom:6}}>
                  <span style={{fontSize:20}}>{a.mimetype?.startsWith("image")?"🖼":a.mimetype?.includes("pdf")?"📄":"📎"}</span>
                  <div style={{flex:1,minWidth:0}}>
                    <div style={{fontSize:12.5,color:"#AEAEB2",fontWeight:500,overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>{a.filename}</div>
                    <div style={{fontSize:10,color:"#636366"}}>{(a.size/1024).toFixed(1)}KB · {a.uploaderName}</div>
                  </div>
                  <a href={`${API}${a.url}`} target="_blank" rel="noreferrer" style={{fontSize:11,color:"#4F8EF7",textDecoration:"none"}}>↓ Download</a>
                  <button onClick={()=>deleteAttachment(a.id)} style={{background:"none",border:"none",color:"#636366",cursor:"pointer",fontSize:14}} onMouseEnter={e=>e.currentTarget.style.color="#FF3B30"} onMouseLeave={e=>e.currentTarget.style.color="#636366"}>✕</button>
                </div>
              ))}
            </div>}

            {/* Activity */}
            {tab==="activity"&&<div style={{padding:"18px 22px"}}>
              {messages.map((m,i)=>(
                <div key={m.id||i} style={{display:"flex",gap:10,marginBottom:16,alignItems:"flex-start"}}>
                  <div style={{width:24,height:24,borderRadius:"50%",background:m.type==="internal"?"#FF950020":m.type==="agent"?"#4F8EF720":"#34C75920",border:`1px solid ${m.type==="internal"?"#FF950040":m.type==="agent"?"#4F8EF740":"#34C75940"}`,display:"flex",alignItems:"center",justifyContent:"center",fontSize:10,color:m.type==="internal"?"#FF9500":m.type==="agent"?"#4F8EF7":"#34C759",flexShrink:0}}>
                    {m.type==="internal"?"🔒":m.type==="agent"?"↑":"↓"}
                  </div>
                  <div>
                    <div style={{fontSize:12,color:"#AEAEB2"}}><strong style={{color:"#F2F2F7"}}>{m.authorName}</strong> {m.type==="internal"?"left a note":m.type==="agent"?"replied to customer":"sent a message"}</div>
                    <div style={{fontSize:10,color:"#636366",marginTop:2}}>{new Date(m.createdAt).toLocaleString()}</div>
                    <div style={{fontSize:12,color:"#636366",marginTop:4,fontStyle:"italic"}}>"{m.body.slice(0,80)}{m.body.length>80?"…":""}"</div>
                  </div>
                </div>
              ))}
            </div>}

            {/* Integrations */}
            {tab==="integrations"&&<div style={{padding:"18px 22px"}}>
              <div style={{fontSize:11,color:"#636366",fontWeight:700,letterSpacing:"0.7px",textTransform:"uppercase",marginBottom:12}}>Quick Actions</div>
              <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:8}}>
                {[{label:"Create Jira Issue",icon:"J",color:"#0052CC"},{label:"Link Linear Task",icon:"L",color:"#5E6AD2"},{label:"Start Zoom Call",icon:"Z",color:"#2D8CFF"},{label:"Post to Slack",icon:"⚡",color:"#E01E5A"},{label:"Schedule Meet",icon:"G",color:"#EA4335"},{label:"Alert PagerDuty",icon:"▲",color:"#06AC38"}].map(a=>(
                  <button key={a.label} onClick={()=>toast(`${a.label} — integration action queued`,"info")} style={{display:"flex",alignItems:"center",gap:10,padding:"12px 14px",background:"#0D0D1E",border:"1px solid #1A1A2E",borderRadius:8,cursor:"pointer",color:"#AEAEB2",fontSize:12,transition:"all 0.15s",fontFamily:"inherit"}}
                    onMouseEnter={e=>{e.currentTarget.style.borderColor=a.color;e.currentTarget.style.color="#F2F2F7";}} onMouseLeave={e=>{e.currentTarget.style.borderColor="#1A1A2E";e.currentTarget.style.color="#AEAEB2";}}>
                    <span style={{width:24,height:24,borderRadius:5,background:a.color,display:"flex",alignItems:"center",justifyContent:"center",fontSize:11,fontWeight:900,color:"#fff",flexShrink:0}}>{a.icon}</span>{a.label}
                  </button>
                ))}
              </div>
            </div>}
          </div>

          {/* Reply Bar */}
          <div style={{padding:"14px 22px",borderTop:"1px solid #1A1A2E",background:"#0A0A1A",flexShrink:0}}>
            <div style={{display:"flex",gap:6,marginBottom:8}}>
              {["agent","internal"].map(t=><button key={t} onClick={()=>setReplyType(t)} style={{padding:"4px 12px",borderRadius:20,background:replyType===t?t==="agent"?"#4F8EF720":"#FF950020":"none",border:`1px solid ${replyType===t?t==="agent"?"#4F8EF740":"#FF950040":"#2D2D3F"}`,color:replyType===t?t==="agent"?"#4F8EF7":"#FF9500":"#636366",fontSize:11,fontWeight:600,cursor:"pointer",fontFamily:"inherit"}}>
                {t==="agent"?"↑ Reply to Customer":"🔒 Internal Note"}
              </button>)}
            </div>
            <div style={{display:"flex",gap:8,alignItems:"flex-end"}}>
              <div style={{flex:1,background:"#0F0F1F",border:"1px solid #2D2D3F",borderRadius:10,overflow:"hidden"}}>
                <textarea value={replyText} onChange={e=>setReplyText(e.target.value)} onKeyDown={e=>{if(e.key==="Enter"&&e.metaKey)sendReply();}} placeholder={replyType==="agent"?"Reply to customer…":"Write internal note (only visible to your team)…"} rows={3}
                  style={{width:"100%",background:"none",border:"none",color:"#AEAEB2",fontSize:13,padding:"10px 13px",outline:"none",fontFamily:"inherit",resize:"none"}}/>
                <div style={{display:"flex",alignItems:"center",gap:6,padding:"5px 10px",borderTop:"1px solid #1E1E2E"}}>
                  <button onClick={()=>fileRef.current?.click()} style={{background:"none",border:"none",cursor:"pointer",fontSize:14,color:"#636366"}} title="Attach file">📎</button>
                  <button style={{background:"none",border:"none",cursor:"pointer",fontSize:14,color:"#636366"}}>📷</button>
                  <span style={{marginLeft:"auto",fontSize:10,color:"#3A3A4E"}}>⌘+Enter to send · Esc to close</span>
                </div>
              </div>
              <div style={{display:"flex",flexDirection:"column",gap:6}}>
                <Btn variant="primary" onClick={sendReply} disabled={sending||!replyText.trim()}>{sending?"…":"Send ↑"}</Btn>
                <Btn variant="ghost" onClick={()=>setReplyType(t=>t==="agent"?"internal":"agent")} style={{fontSize:10}}>Switch</Btn>
              </div>
            </div>
          </div>
        </div>

        {/* Detail Panel */}
        {detailOpen&&<div style={{width:300,background:"#060614",borderLeft:"1px solid #1A1A2E",display:"flex",flexDirection:"column",overflow:"hidden",flexShrink:0,animation:"slInR 0.22s ease"}}>
          <div style={{padding:"12px 14px",borderBottom:"1px solid #1A1A2E",display:"flex",alignItems:"center",justifyContent:"space-between",background:"#0A0A1A"}}>
            <span style={{fontSize:12,fontWeight:700,color:"#F2F2F7"}}>Details</span>
            <button onClick={()=>setDetailOpen(false)} style={{background:"none",border:"none",color:"#636366",cursor:"pointer",fontSize:14}}
              onMouseEnter={e=>e.currentTarget.style.color="#FF3B30"} onMouseLeave={e=>e.currentTarget.style.color="#636366"}>⇥</button>
          </div>
          <div style={{flex:1,overflow:"auto",padding:12}}>
            {/* Assignee */}
            <div style={{marginBottom:14}}>
              <div style={{fontSize:10,color:"#636366",fontWeight:700,letterSpacing:"0.7px",textTransform:"uppercase",marginBottom:6}}>Assignee</div>
              <div style={{display:"flex",alignItems:"center",gap:8,padding:"8px 10px",background:"#0D0D1E",borderRadius:8,border:"1px solid #1A1A2E",cursor:"pointer"}} onClick={()=>setModal("assign")}>
                <Avatar agent={ticket.assignee} size={26}/>
                <div style={{flex:1}}><div style={{fontSize:12,color:"#E5E5EA",fontWeight:600}}>{ticket.assignee?.name||"Unassigned"}</div>{ticket.assignee&&<div style={{fontSize:10,color:{online:"#34C759",busy:"#FF3B30",away:"#FF9500",offline:"#636366"}[ticket.assignee.status||"offline"]}}>{ticket.assignee.status}</div>}</div>
                <span style={{fontSize:11,color:"#4F8EF7"}}>Edit</span>
              </div>
            </div>
            {/* Properties */}
            <div style={{marginBottom:14}}>
              <div style={{fontSize:10,color:"#636366",fontWeight:700,letterSpacing:"0.7px",textTransform:"uppercase",marginBottom:6}}>Properties</div>
              {[
                {label:"Status",  el:<div onClick={()=>setModal("status")} style={{cursor:"pointer"}}><StatusBadge s={ticket.status}/></div>},
                {label:"Priority",el:<PriorityDot p={ticket.priority}/>},
                {label:"Channel", el:<ChannelBadge ch={ticket.channel}/>},
                {label:"Created", el:<span style={{fontSize:11,color:"#AEAEB2"}}>{new Date(ticket.createdAt).toLocaleDateString()}</span>},
                {label:"Messages",el:<span style={{fontSize:11,color:"#AEAEB2"}}>💬 {messages.length}</span>},
                {label:"Files",   el:<span style={{fontSize:11,color:"#AEAEB2"}}>📎 {attachments.length}</span>},
              ].map(({label,el})=>(
                <div key={label} style={{display:"flex",justifyContent:"space-between",alignItems:"center",padding:"6px 0",borderBottom:"1px solid #0D0D1A"}}>
                  <span style={{fontSize:11,color:"#636366"}}>{label}</span>{el}
                </div>
              ))}
            </div>
            {/* Customer */}
            <div style={{marginBottom:14}}>
              <div style={{fontSize:10,color:"#636366",fontWeight:700,letterSpacing:"0.7px",textTransform:"uppercase",marginBottom:6}}>Customer</div>
              <div style={{background:"#0D0D1E",border:"1px solid #1A1A2E",borderRadius:8,padding:10}}>
                <div style={{fontSize:12,fontWeight:700,color:"#F2F2F7",marginBottom:2}}>{ticket.customer}</div>
                <div style={{fontSize:11,color:"#636366",marginBottom:6,wordBreak:"break-all"}}>{ticket.customerEmail}</div>
                <div style={{display:"flex",gap:4}}>
                  {(ticket.customFields?.tier)&&<span style={{padding:"2px 6px",background:"#A855F720",border:"1px solid #A855F740",borderRadius:10,fontSize:9,color:"#A855F7",fontWeight:700}}>{ticket.customFields.tier}</span>}
                  {ticket.customFields?.contractValue&&<span style={{padding:"2px 6px",background:"#34C75920",border:"1px solid #34C75940",borderRadius:10,fontSize:9,color:"#34C759",fontWeight:700}}>{ticket.customFields.contractValue}</span>}
                </div>
              </div>
            </div>
            {/* SLA */}
            <div style={{marginBottom:14}}>
              <div style={{fontSize:10,color:"#636366",fontWeight:700,letterSpacing:"0.7px",textTransform:"uppercase",marginBottom:6}}>SLA</div>
              <div style={{background:"#0D0D1E",border:"1px solid #1A1A2E",borderRadius:8,padding:10}}><SlaBar pct={ticket.slaPct} sla={ticket.sla}/><div style={{fontSize:11,color:"#636366",marginTop:5}}>{ticket.sla>60?`${Math.floor(ticket.sla/60)}h ${ticket.sla%60}m`:`${ticket.sla}m`} remaining</div></div>
            </div>
            {/* Linked */}
            <div>
              <div style={{fontSize:10,color:"#636366",fontWeight:700,letterSpacing:"0.7px",textTransform:"uppercase",marginBottom:6}}>Linked Issues</div>
              <div style={{display:"flex",flexDirection:"column",gap:5}}>
                {ticket.jira&&<div style={{display:"flex",alignItems:"center",gap:8,padding:"7px 10px",background:"#0D0D1E",border:"1px solid #1A1A2E",borderRadius:7}}><span style={{width:18,height:18,borderRadius:4,background:"#0052CC",display:"flex",alignItems:"center",justifyContent:"center",fontSize:9,fontWeight:900,color:"#fff"}}>J</span><span style={{fontSize:11,color:"#4F8EF7",fontFamily:"'DM Mono',monospace"}}>{ticket.jira}</span><span style={{marginLeft:"auto",fontSize:10,color:"#636366"}}>↗</span></div>}
                {ticket.linear&&<div style={{display:"flex",alignItems:"center",gap:8,padding:"7px 10px",background:"#0D0D1E",border:"1px solid #1A1A2E",borderRadius:7}}><span style={{width:18,height:18,borderRadius:4,background:"#5E6AD2",display:"flex",alignItems:"center",justifyContent:"center",fontSize:9,fontWeight:900,color:"#fff"}}>L</span><span style={{fontSize:11,color:"#5E6AD2",fontFamily:"'DM Mono',monospace"}}>{ticket.linear}</span><span style={{marginLeft:"auto",fontSize:10,color:"#636366"}}>↗</span></div>}
                {!ticket.jira&&!ticket.linear&&<span style={{fontSize:11,color:"#3A3A4E"}}>None linked</span>}
              </div>
            </div>
          </div>
        </div>}
      </div>

      {/* Sub-modals */}
      {modal==="assign"&&<AssignModal ticket={ticket} agents={agents} onClose={()=>setModal(null)} onAssigned={t=>{setTicket(t);onUpdated(t);}}/>}
      {modal==="status"&&<StatusModal ticket={ticket} onClose={()=>setModal(null)} onUpdated={t=>{setTicket(t);onUpdated(t);}}/>}
    </>
  );
}

// ─── Ticket Row ───────────────────────────────────────────────────────────────
function TicketRow({ ticket, onClick }) {
  return (
    <div onClick={onClick} style={{display:"grid",gridTemplateColumns:"14px 1fr auto",gap:12,alignItems:"start",padding:"13px 18px",borderBottom:"1px solid #0D0D1A",background:ticket.unread?"#090917":"transparent",cursor:"pointer",transition:"background 0.12s",borderLeft:ticket.unread?"3px solid #4F8EF750":"3px solid transparent"}}
      onMouseEnter={e=>e.currentTarget.style.background="#0E0E1E"} onMouseLeave={e=>e.currentTarget.style.background=ticket.unread?"#090917":"transparent"}>
      <div style={{paddingTop:5}}>{ticket.unread&&<div style={{width:7,height:7,borderRadius:"50%",background:"#4F8EF7",boxShadow:"0 0 6px #4F8EF7"}}/>}</div>
      <div style={{minWidth:0}}>
        <div style={{display:"flex",alignItems:"center",gap:6,marginBottom:5,flexWrap:"wrap"}}>
          <span style={{fontSize:11,color:"#636366",fontFamily:"'DM Mono',monospace"}}>{ticket.id}</span>
          <PriorityDot p={ticket.priority}/><ChannelBadge ch={ticket.channel}/><StatusBadge s={ticket.status}/>
        </div>
        <div style={{fontSize:13.5,fontWeight:ticket.unread?700:500,color:ticket.unread?"#F2F2F7":"#AEAEB2",marginBottom:5,lineHeight:1.4}}>{ticket.title}</div>
        <div style={{display:"flex",alignItems:"center",gap:6,flexWrap:"wrap"}}>
          <span style={{fontSize:11,color:"#636366"}}>{ticket.customer}</span>
          {(ticket.tags||[]).map(t=><Tag key={t} label={t}/>)}
          {ticket.jira&&<IntBadge type="jira" id={ticket.jira}/>}{ticket.linear&&<IntBadge type="linear" id={ticket.linear}/>}
        </div>
      </div>
      <div style={{display:"flex",flexDirection:"column",alignItems:"flex-end",gap:6,minWidth:110}}>
        <div style={{display:"flex",alignItems:"center",gap:6}}><Avatar agent={ticket.assignee} size={22}/><span style={{fontSize:10,color:"#636366"}}>{ticket.messageCount||0}m ago</span></div>
        <SlaBar pct={ticket.slaPct||0} sla={ticket.sla||480}/>
        <span style={{fontSize:10,color:"#636366"}}>💬 {ticket.messageCount||0}</span>
      </div>
    </div>
  );
}

// ─── Kanban ───────────────────────────────────────────────────────────────────
function KanbanBoard({ tickets, onOpen }) {
  const COLS = ["open","pending","on-hold","resolved","closed"];
  return (
    <div style={{display:"flex",gap:12,padding:18,overflowX:"auto",height:"100%",alignItems:"flex-start"}}>
      {COLS.map(col=>{
        const ct=tickets.filter(t=>t.status===col); const s=STATUSES[col];
        return (
          <div key={col} style={{minWidth:260,flex:"0 0 260px"}}>
            <div style={{display:"flex",alignItems:"center",justifyContent:"space-between",marginBottom:10,padding:"0 2px"}}>
              <div style={{display:"flex",alignItems:"center",gap:6}}><div style={{width:7,height:7,borderRadius:"50%",background:s.color}}/><span style={{fontSize:11,fontWeight:700,color:s.color,letterSpacing:"0.5px",textTransform:"uppercase"}}>{s.label}</span></div>
              <span style={{fontSize:11,color:"#636366",background:"#1E1E2E",borderRadius:10,padding:"1px 7px",border:"1px solid #2D2D3F"}}>{ct.length}</span>
            </div>
            <div style={{display:"flex",flexDirection:"column",gap:8}}>
              {ct.map(t=>(
                <div key={t.id} onClick={()=>onOpen(t.id)} style={{background:"#0F0F1F",border:"1px solid #1E1E2E",borderRadius:8,padding:12,cursor:"pointer",transition:"all 0.15s",borderTop:`2px solid ${PRIORITIES[t.priority]?.color||"#4F8EF7"}`}}
                  onMouseEnter={e=>{e.currentTarget.style.borderColor="#3A3A4E";e.currentTarget.style.transform="translateY(-1px)";}} onMouseLeave={e=>{e.currentTarget.style.borderColor="#1E1E2E";e.currentTarget.style.transform="translateY(0)";}}>
                  <div style={{display:"flex",justifyContent:"space-between",marginBottom:6}}><span style={{fontSize:10,color:"#636366",fontFamily:"'DM Mono',monospace"}}>{t.id}</span><ChannelBadge ch={t.channel}/></div>
                  <div style={{fontSize:12.5,fontWeight:600,color:"#AEAEB2",marginBottom:8,lineHeight:1.4}}>{t.title}</div>
                  <div style={{display:"flex",justifyContent:"space-between",alignItems:"center"}}><PriorityDot p={t.priority}/><Avatar agent={t.assignee} size={20}/></div>
                  <div style={{marginTop:8}}><SlaBar pct={t.slaPct||0} sla={t.sla||480}/></div>
                </div>
              ))}
              {ct.length===0&&<div style={{padding:20,textAlign:"center",border:"1px dashed #1E1E2E",borderRadius:8,color:"#3A3A4E",fontSize:12}}>Empty</div>}
            </div>
          </div>
        );
      })}
    </div>
  );
}

// ─── Reports Page ─────────────────────────────────────────────────────────────
function ReportsPage() {
  const api = useApi(); const [data, setData] = useState(null);
  useEffect(() => { api.get("/reports/overview").then(setData).catch(()=>{}); },[]);
  if (!data) return <div style={{display:"flex",alignItems:"center",justifyContent:"center",height:"100%",color:"#636366",fontSize:13}}>Loading reports…</div>;

  const StatCard = ({label,value,color,sub}) => (
    <div style={{background:"#0A0A18",border:"1px solid #1A1A2E",borderRadius:10,padding:"16px 18px"}}>
      <div style={{fontSize:11,color:"#636366",fontWeight:700,letterSpacing:"0.7px",textTransform:"uppercase",marginBottom:6}}>{label}</div>
      <div style={{fontSize:28,fontWeight:800,color:color||"#F2F2F7",fontFamily:"'DM Mono',monospace",lineHeight:1}}>{value}</div>
      {sub&&<div style={{fontSize:11,color:"#636366",marginTop:4}}>{sub}</div>}
    </div>
  );

  return (
    <div style={{padding:24,overflow:"auto",height:"100%"}}>
      <h2 style={{fontSize:19,fontWeight:800,color:"#F2F2F7",marginBottom:4}}>Reports & Analytics</h2>
      <p style={{fontSize:13,color:"#636366",marginBottom:20}}>Overview of your support team's performance</p>
      <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fill,minmax(160px,1fr))",gap:12,marginBottom:24}}>
        <StatCard label="Total Tickets" value={data.totals.tickets} sub="All time"/>
        <StatCard label="Open" value={data.totals.open} color="#4F8EF7" sub="Needs attention"/>
        <StatCard label="Resolved" value={data.totals.resolved} color="#34C759" sub="Closed out"/>
        <StatCard label="Avg Response" value={data.totals.avgResponseTime} color="#FF9500" sub="First reply time"/>
        <StatCard label="SLA Breaches" value={data.totals.slaBreaches} color="#FF3B30" sub="Last 30 days"/>
      </div>
      <div style={{display:"grid",gridTemplateColumns:"1fr 1fr 1fr",gap:14,marginBottom:24}}>
        {/* By Status */}
        <div style={{background:"#0A0A18",border:"1px solid #1A1A2E",borderRadius:10,padding:16}}>
          <div style={{fontSize:12,fontWeight:700,color:"#F2F2F7",marginBottom:12}}>By Status</div>
          {Object.entries(data.byStatus).map(([k,v])=>{ const s=STATUSES[k]; return (
            <div key={k} style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:8}}>
              <div style={{display:"flex",alignItems:"center",gap:6}}><div style={{width:8,height:8,borderRadius:"50%",background:s.color}}/><span style={{fontSize:12,color:"#AEAEB2"}}>{s.label}</span></div>
              <div style={{display:"flex",alignItems:"center",gap:8}}>
                <div style={{width:60,height:4,background:"#1E1E2E",borderRadius:2,overflow:"hidden"}}><div style={{width:`${data.totals.tickets?v/data.totals.tickets*100:0}%`,height:"100%",background:s.color}}/></div>
                <span style={{fontSize:11,color:s.color,fontFamily:"'DM Mono',monospace",minWidth:16,textAlign:"right"}}>{v}</span>
              </div>
            </div>
          );})}
        </div>
        {/* By Priority */}
        <div style={{background:"#0A0A18",border:"1px solid #1A1A2E",borderRadius:10,padding:16}}>
          <div style={{fontSize:12,fontWeight:700,color:"#F2F2F7",marginBottom:12}}>By Priority</div>
          {Object.entries(data.byPriority).map(([k,v])=>{ const p=PRIORITIES[k]; return (
            <div key={k} style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:8}}>
              <div style={{display:"flex",alignItems:"center",gap:6}}><div style={{width:8,height:8,borderRadius:"50%",background:p.color}}/><span style={{fontSize:12,color:"#AEAEB2"}}>{p.label}</span></div>
              <div style={{display:"flex",alignItems:"center",gap:8}}>
                <div style={{width:60,height:4,background:"#1E1E2E",borderRadius:2,overflow:"hidden"}}><div style={{width:`${data.totals.tickets?v/data.totals.tickets*100:0}%`,height:"100%",background:p.color}}/></div>
                <span style={{fontSize:11,color:p.color,fontFamily:"'DM Mono',monospace",minWidth:16,textAlign:"right"}}>{v}</span>
              </div>
            </div>
          );})}
        </div>
        {/* By Channel */}
        <div style={{background:"#0A0A18",border:"1px solid #1A1A2E",borderRadius:10,padding:16}}>
          <div style={{fontSize:12,fontWeight:700,color:"#F2F2F7",marginBottom:12}}>By Channel</div>
          {Object.entries(data.byChannel).map(([k,v])=>{ const c=CHANNELS[k]; return (
            <div key={k} style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:8}}>
              <div style={{display:"flex",alignItems:"center",gap:6}}><span style={{fontSize:11,color:c.color}}>{c.icon}</span><span style={{fontSize:12,color:"#AEAEB2"}}>{c.label}</span></div>
              <div style={{display:"flex",alignItems:"center",gap:8}}>
                <div style={{width:60,height:4,background:"#1E1E2E",borderRadius:2,overflow:"hidden"}}><div style={{width:`${data.totals.tickets?v/data.totals.tickets*100:0}%`,height:"100%",background:c.color}}/></div>
                <span style={{fontSize:11,color:c.color,fontFamily:"'DM Mono',monospace",minWidth:16,textAlign:"right"}}>{v}</span>
              </div>
            </div>
          );})}
        </div>
      </div>
      {/* Agent Stats */}
      <div style={{background:"#0A0A18",border:"1px solid #1A1A2E",borderRadius:10,padding:16}}>
        <div style={{fontSize:12,fontWeight:700,color:"#F2F2F7",marginBottom:14}}>Agent Performance</div>
        <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fill,minmax(180px,1fr))",gap:10}}>
          {data.agentStats.map(a=>(
            <div key={a.id} style={{background:"#080818",border:"1px solid #1E1E2E",borderRadius:8,padding:12}}>
              <div style={{display:"flex",alignItems:"center",gap:8,marginBottom:8}}><Avatar agent={a} size={26}/><span style={{fontSize:12,fontWeight:600,color:"#AEAEB2"}}>{a.name}</span></div>
              <div style={{display:"flex",gap:10}}>
                <div><div style={{fontSize:16,fontWeight:800,color:"#4F8EF7",fontFamily:"'DM Mono',monospace"}}>{a.open}</div><div style={{fontSize:10,color:"#636366"}}>Open</div></div>
                <div><div style={{fontSize:16,fontWeight:800,color:"#34C759",fontFamily:"'DM Mono',monospace"}}>{a.resolved}</div><div style={{fontSize:10,color:"#636366"}}>Resolved</div></div>
                <div><div style={{fontSize:16,fontWeight:800,color:"#AEAEB2",fontFamily:"'DM Mono',monospace"}}>{a.total}</div><div style={{fontSize:10,color:"#636366"}}>Total</div></div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

// ─── Customers Page ───────────────────────────────────────────────────────────
function CustomersPage() {
  const api = useApi(); const [customers, setCustomers] = useState([]);
  useEffect(()=>{ api.get("/customers").then(d=>setCustomers(d.customers)).catch(()=>{}); },[]);
  return (
    <div style={{padding:24,overflow:"auto",height:"100%"}}>
      <h2 style={{fontSize:19,fontWeight:800,color:"#F2F2F7",marginBottom:4}}>Customers</h2>
      <p style={{fontSize:13,color:"#636366",marginBottom:20}}>All customers who have submitted support tickets</p>
      <div style={{background:"#0A0A18",border:"1px solid #1A1A2E",borderRadius:10,overflow:"hidden"}}>
        <div style={{display:"grid",gridTemplateColumns:"1fr 80px 60px 120px",gap:12,padding:"10px 16px",borderBottom:"1px solid #1A1A2E",fontSize:10,color:"#636366",fontWeight:700,letterSpacing:"1px",textTransform:"uppercase"}}>
          <span>Customer</span><span>Tickets</span><span>Open</span><span>Last Seen</span>
        </div>
        {customers.map(c=>(
          <div key={c.email} style={{display:"grid",gridTemplateColumns:"1fr 80px 60px 120px",gap:12,padding:"11px 16px",borderBottom:"1px solid #0D0D1A",alignItems:"center",transition:"background 0.1s",cursor:"pointer"}}
            onMouseEnter={e=>e.currentTarget.style.background="#0F0F1F"} onMouseLeave={e=>e.currentTarget.style.background="transparent"}>
            <div><div style={{fontSize:13,fontWeight:600,color:"#E5E5EA"}}>{c.name}</div><div style={{fontSize:11,color:"#636366"}}>{c.email}</div></div>
            <span style={{fontSize:12,color:"#AEAEB2",fontFamily:"'DM Mono',monospace"}}>{c.tickets}</span>
            <span style={{fontSize:12,color:c.open>0?"#FF9500":"#636366",fontFamily:"'DM Mono',monospace"}}>{c.open}</span>
            <span style={{fontSize:11,color:"#636366"}}>{new Date(c.lastSeen).toLocaleDateString()}</span>
          </div>
        ))}
        {customers.length===0&&<div style={{padding:"30px",textAlign:"center",color:"#636366",fontSize:13}}>No customers yet</div>}
      </div>
    </div>
  );
}

// ─── Settings Page ────────────────────────────────────────────────────────────
function SettingsPage({ user, org, onOrgUpdate }) {
  const api = useApi(); const toast = useToast();
  const [section, setSection] = useState("integrations");
  const [integrations, setIntegrations] = useState({});
  const [team, setTeam] = useState({ members:[], pendingInvites:[] });
  const [billing, setBilling] = useState(null);
  const [intModal, setIntModal] = useState(null);
  const [showInvite, setShowInvite] = useState(false);
  const [billingInterval, setBillingInterval] = useState("monthly");

  const SECTIONS = [
    {id:"integrations",label:"Integrations",icon:"⬡"},
    {id:"team",        label:"Team & Roles", icon:"◯"},
    {id:"billing",     label:"Billing",      icon:"💳"},
    {id:"sla",         label:"SLA Policies", icon:"◎"},
    {id:"appearance",  label:"Appearance",   icon:"◈"},
  ];

  useEffect(()=>{
    if(section==="integrations") api.get("/integrations").then(d=>setIntegrations(d.integrations||{})).catch(()=>{});
    if(section==="team") api.get("/team").then(setTeam).catch(()=>{});
    if(section==="billing"&&user.role==="admin") api.get("/billing").then(setBilling).catch(()=>{});
  },[section]);

  const cats = [...new Set(Object.values(INTEGRATION_META).map(m=>m.cat))];

  return (
    <div style={{display:"flex",height:"100%",overflow:"hidden"}}>
      <div style={{width:190,background:"#0A0A18",borderRight:"1px solid #12121E",padding:"14px 0",flexShrink:0}}>
        <div style={{fontSize:10,color:"#636366",fontWeight:700,letterSpacing:"1px",textTransform:"uppercase",padding:"0 13px",marginBottom:9}}>Settings</div>
        {SECTIONS.map(s=>(
          <button key={s.id} onClick={()=>setSection(s.id)} style={{width:"100%",display:"flex",alignItems:"center",gap:8,padding:"9px 13px",background:section===s.id?"#1A1A2E":"none",border:"none",borderRight:section===s.id?"2px solid #4F8EF7":"2px solid transparent",color:section===s.id?"#F2F2F7":"#636366",cursor:"pointer",fontSize:12.5,fontWeight:section===s.id?600:400,transition:"all 0.15s",textAlign:"left",fontFamily:"inherit"}}>
            <span>{s.icon}</span>{s.label}
          </button>
        ))}
      </div>
      <div style={{flex:1,overflow:"auto",padding:24}}>

        {/* Integrations */}
        {section==="integrations"&&<>
          <h2 style={{fontSize:19,fontWeight:800,color:"#F2F2F7",marginBottom:4}}>Integrations</h2>
          <p style={{fontSize:13,color:"#636366",marginBottom:22}}>Connect your tools. Each integration's scope and permissions are clearly documented.</p>
          {cats.map(cat=>(
            <div key={cat} style={{marginBottom:26}}>
              <div style={{fontSize:11,color:"#636366",fontWeight:700,letterSpacing:"1px",textTransform:"uppercase",marginBottom:10,paddingBottom:7,borderBottom:"1px solid #1A1A2E"}}>{cat}</div>
              <div style={{display:"flex",flexDirection:"column",gap:7}}>
                {Object.entries(INTEGRATION_META).filter(([,m])=>m.cat===cat).map(([id,meta])=>{
                  const int = integrations[id]||{};
                  return (
                    <div key={id} style={{background:"#0A0A18",border:"1px solid #1A1A2E",borderRadius:10}}>
                      <div style={{display:"flex",alignItems:"center",gap:12,padding:"13px 16px"}}>
                        <div style={{width:36,height:36,borderRadius:9,background:`${meta.color}20`,border:`1px solid ${meta.color}40`,display:"flex",alignItems:"center",justifyContent:"center",fontSize:15,color:meta.color,fontWeight:900,flexShrink:0}}>{meta.icon}</div>
                        <div style={{flex:1}}>
                          <div style={{fontSize:13,fontWeight:700,color:"#F2F2F7"}}>{meta.name}</div>
                          <div style={{fontSize:11,color:int.connected?"#34C759":"#636366",marginTop:1}}>{int.connected?"● Connected · "+new Date(int.connectedAt).toLocaleDateString():"○ Not connected"}</div>
                        </div>
                        <div style={{display:"flex",gap:8,alignItems:"center"}}>
                          {int.connected&&<div style={{display:"flex",alignItems:"center",gap:4,padding:"3px 8px",background:"#34C75912",border:"1px solid #34C75930",borderRadius:20}}><div style={{width:5,height:5,borderRadius:"50%",background:"#34C759"}}/><span style={{fontSize:10,color:"#34C759",fontWeight:700}}>Live</span></div>}
                          <Btn onClick={()=>setIntModal({id,meta,int})}>{int.connected?"⚙ Configure":"+ Connect"}</Btn>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          ))}
        </>}

        {/* Team */}
        {section==="team"&&<>
          <div style={{display:"flex",alignItems:"center",justifyContent:"space-between",marginBottom:18}}>
            <div><h2 style={{fontSize:19,fontWeight:800,color:"#F2F2F7",marginBottom:2}}>Team & Roles</h2><p style={{fontSize:13,color:"#636366"}}>Manage your agents, roles, and pending invites.</p></div>
            {user.role==="admin"&&<Btn variant="primary" onClick={()=>setShowInvite(true)}>+ Invite Member</Btn>}
          </div>
          {/* Members */}
          <div style={{background:"#0A0A18",border:"1px solid #1A1A2E",borderRadius:10,overflow:"hidden",marginBottom:16}}>
            <div style={{padding:"10px 16px",borderBottom:"1px solid #1A1A2E",fontSize:11,color:"#636366",fontWeight:700,letterSpacing:"0.7px",textTransform:"uppercase"}}>Members ({team.members?.length||0})</div>
            {team.members?.map(m=>(
              <div key={m.id} style={{display:"flex",alignItems:"center",gap:12,padding:"12px 16px",borderBottom:"1px solid #0D0D1A"}}>
                <Avatar agent={m} size={32}/>
                <div style={{flex:1}}>
                  <div style={{fontSize:13,fontWeight:600,color:"#F2F2F7"}}>{m.name} {m.id===user.id&&<span style={{fontSize:10,color:"#636366",fontStyle:"italic"}}>(you)</span>}</div>
                  <div style={{fontSize:11,color:"#636366"}}>{m.email}</div>
                </div>
                <span style={{padding:"3px 10px",borderRadius:20,background:{admin:"#FF950020",agent:"#4F8EF720",viewer:"#A855F720"}[m.role],border:`1px solid ${m.role==="admin"?"#FF950040":m.role==="agent"?"#4F8EF740":"#A855F740"}`,fontSize:10,color:{admin:"#FF9500",agent:"#4F8EF7",viewer:"#A855F7"}[m.role],fontWeight:700,textTransform:"capitalize"}}>{m.role}</span>
                {user.role==="admin"&&m.id!==user.id&&<>
                  <select value={m.role} onChange={async e=>{ try{const d=await api.patch(`/team/${m.id}`,{role:e.target.value});setTeam(t=>({...t,members:t.members.map(x=>x.id===m.id?d.user:x)}));toast("Role updated","success");}catch(err){toast(err.message,"error");} }} style={{background:"#080818",border:"1px solid #2D2D3F",borderRadius:6,color:"#AEAEB2",fontSize:11,padding:"4px 8px",cursor:"pointer",fontFamily:"inherit"}}>
                    {ROLES.map(r=><option key={r} value={r}>{r}</option>)}
                  </select>
                  <Btn variant="danger" onClick={async()=>{ if(!window.confirm(`Remove ${m.name}?`))return; try{await api.del(`/team/${m.id}`);setTeam(t=>({...t,members:t.members.filter(x=>x.id!==m.id)}));toast("Member removed","info");}catch(e){toast(e.message,"error");} }}>Remove</Btn>
                </>}
              </div>
            ))}
          </div>
          {/* Pending Invites */}
          {team.pendingInvites?.length>0&&<div style={{background:"#0A0A18",border:"1px solid #1A1A2E",borderRadius:10,overflow:"hidden"}}>
            <div style={{padding:"10px 16px",borderBottom:"1px solid #1A1A2E",fontSize:11,color:"#636366",fontWeight:700,letterSpacing:"0.7px",textTransform:"uppercase"}}>Pending Invites ({team.pendingInvites.length})</div>
            {team.pendingInvites.map(inv=>(
              <div key={inv.id} style={{display:"flex",alignItems:"center",gap:12,padding:"11px 16px",borderBottom:"1px solid #0D0D1A"}}>
                <div style={{flex:1}}><div style={{fontSize:13,color:"#AEAEB2"}}>{inv.email}</div><div style={{fontSize:11,color:"#636366"}}>Invited as {inv.role} · Expires {new Date(inv.expiresAt).toLocaleDateString()}</div></div>
                <span style={{padding:"2px 8px",background:"#FF950020",border:"1px solid #FF950040",borderRadius:10,fontSize:10,color:"#FF9500",fontWeight:700}}>Pending</span>
                {user.role==="admin"&&<Btn variant="danger" onClick={async()=>{ try{await api.del(`/team/invites/${inv.id}`);setTeam(t=>({...t,pendingInvites:t.pendingInvites.filter(x=>x.id!==inv.id)}));toast("Invite revoked","info");}catch(e){toast(e.message,"error");} }}>Revoke</Btn>}
              </div>
            ))}
          </div>}
        </>}

        {/* Billing */}
        {section==="billing"&&<>
          {user.role!=="admin"?<div style={{color:"#636366",fontSize:13,padding:"40px 0",textAlign:"center"}}>Only admins can view billing.</div>:<>
            <h2 style={{fontSize:19,fontWeight:800,color:"#F2F2F7",marginBottom:4}}>Billing & Plans</h2>
            <p style={{fontSize:13,color:"#636366",marginBottom:20}}>Manage your subscription and billing details.</p>
            {billing&&<>
              {/* Current Plan */}
              <div style={{background:"#0A0A18",border:"1px solid #1A1A2E",borderRadius:10,padding:18,marginBottom:18}}>
                <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:14}}>
                  <div>
                    <div style={{fontSize:11,color:"#636366",fontWeight:700,letterSpacing:"0.7px",textTransform:"uppercase",marginBottom:4}}>Current Plan</div>
                    <div style={{fontSize:20,fontWeight:800,color:"#F2F2F7"}}>{PLANS[billing.billing?.plan||"free"]?.name||"Free"}</div>
                    <div style={{fontSize:12,color:"#636366",marginTop:2}}>{billing.billing?.interval==="annual"?"Billed annually":"Billed monthly"} · ${billing.billing?.amount||0}/period</div>
                  </div>
                  <div style={{textAlign:"right"}}>
                    <div style={{fontSize:11,color:"#636366",marginBottom:2}}>Seats used</div>
                    <div style={{fontSize:16,fontWeight:700,color:"#AEAEB2",fontFamily:"'DM Mono',monospace"}}>{billing.org?.usedSeats||0} / {billing.org?.seats===999?"∞":billing.org?.seats||0}</div>
                    <div style={{fontSize:11,color:"#636366",marginTop:2}}>Next billing: {billing.billing?.nextBillingDate||"N/A"}</div>
                  </div>
                </div>
                {billing.billing?.paymentMethod&&<div style={{display:"flex",alignItems:"center",gap:8,padding:"8px 12px",background:"#080818",borderRadius:8,border:"1px solid #1E1E2E",display:"inline-flex"}}>
                  <span style={{fontSize:13}}>💳</span>
                  <span style={{fontSize:12,color:"#AEAEB2"}}>{billing.billing.paymentMethod.brand} ···· {billing.billing.paymentMethod.last4}</span>
                </div>}
              </div>
              {/* Plan interval toggle */}
              <div style={{display:"flex",alignItems:"center",gap:10,marginBottom:14}}>
                <span style={{fontSize:12,color:"#636366"}}>Monthly</span>
                <Toggle value={billingInterval==="annual"} onChange={v=>setBillingInterval(v?"annual":"monthly")}/>
                <span style={{fontSize:12,color:"#636366"}}>Annual <span style={{color:"#34C759",fontSize:10,fontWeight:700"}}>Save 17%</span></span>
              </div>
              {/* Plan cards */}
              <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fill,minmax(200px,1fr))",gap:12,marginBottom:22}}>
                {Object.entries(PLANS).map(([planId,p])=>{
                  const isCurrent = (billing.billing?.plan||"free")===planId;
                  const price = billingInterval==="annual" ? p.annualPrice : p.price;
                  return (
                    <div key={planId} style={{background:isCurrent?"#1A1A2E":"#0A0A18",border:`1px solid ${isCurrent?"#4F8EF7":"#1A1A2E"}`,borderRadius:10,padding:16,position:"relative"}}>
                      {isCurrent&&<div style={{position:"absolute",top:-1,right:12,background:"#4F8EF7",color:"#fff",fontSize:9,fontWeight:800,padding:"2px 8px",borderRadius:"0 0 6px 6px",letterSpacing:"0.5px"}}>CURRENT</div>}
                      <div style={{fontSize:14,fontWeight:800,color:"#F2F2F7",marginBottom:4}}>{p.name}</div>
                      <div style={{fontSize:20,fontWeight:800,color:"#4F8EF7",fontFamily:"'DM Mono',monospace",marginBottom:2}}>${price}<span style={{fontSize:11,color:"#636366",fontWeight:400,fontFamily:"inherit"}}>/{billingInterval==="annual"?"yr":"mo"}</span></div>
                      <div style={{fontSize:11,color:"#636366",marginBottom:12}}>{p.seats===999?"Unlimited":p.seats} agents</div>
                      <div style={{display:"flex",flexDirection:"column",gap:4,marginBottom:14}}>
                        {(billing.plans?.[planId]?.features||[]).map(f=><div key={f} style={{fontSize:11,color:"#8E8E93",display:"flex",gap:5}}><span style={{color:"#34C759"}}>✓</span>{f}</div>)}
                      </div>
                      {!isCurrent&&<Btn variant={planId==="enterprise"?"primary":"ghost"} size="sm" onClick={async()=>{ try{const d=await api.post("/billing/upgrade",{plan:planId,interval:billingInterval});setBilling(b=>({...b,billing:d.billing,org:d.org}));toast(`Upgraded to ${p.name}!`,"success");}catch(e){toast(e.message,"error");} }} style={{width:"100%"}}>
                        {planId==="enterprise"?"Contact Sales":price>((billingInterval==="annual"?PLANS[billing.billing?.plan||"free"]?.annualPrice:PLANS[billing.billing?.plan||"free"]?.price)||0)?"Upgrade":"Downgrade"}
                      </Btn>}
                    </div>
                  );
                })}
              </div>
              {/* Invoices */}
              {billing.billing?.invoices?.length>0&&<div style={{background:"#0A0A18",border:"1px solid #1A1A2E",borderRadius:10,overflow:"hidden"}}>
                <div style={{padding:"10px 16px",borderBottom:"1px solid #1A1A2E",fontSize:11,color:"#636366",fontWeight:700,letterSpacing:"0.7px",textTransform:"uppercase"}}>Invoices</div>
                {billing.billing.invoices.map(inv=>(
                  <div key={inv.id} style={{display:"flex",alignItems:"center",gap:12,padding:"11px 16px",borderBottom:"1px solid #0D0D1A"}}>
                    <span style={{fontSize:11,color:"#636366",fontFamily:"'DM Mono',monospace"}}>{inv.id}</span>
                    <span style={{flex:1,fontSize:12,color:"#AEAEB2"}}>{inv.date}</span>
                    <span style={{fontSize:12,fontWeight:700,color:"#F2F2F7",fontFamily:"'DM Mono',monospace"}}>${inv.amount}</span>
                    <span style={{padding:"2px 8px",background:"#34C75920",border:"1px solid #34C75940",borderRadius:10,fontSize:10,color:"#34C759",fontWeight:700,textTransform:"capitalize"}}>{inv.status}</span>
                    <button style={{background:"none",border:"none",color:"#4F8EF7",cursor:"pointer",fontSize:11}} onClick={()=>toast("Invoice download coming soon","info")}>↓ PDF</button>
                  </div>
                ))}
              </div>}
            </>}
          </>}
        </>}

        {!["integrations","team","billing"].includes(section)&&<div style={{display:"flex",alignItems:"center",justifyContent:"center",height:"60%",flexDirection:"column",gap:10}}>
          <div style={{fontSize:36,opacity:0.2}}>{SECTIONS.find(s=>s.id===section)?.icon}</div>
          <div style={{fontSize:15,color:"#3A3A4E",fontWeight:600}}>{SECTIONS.find(s=>s.id===section)?.label}</div>
          <div style={{fontSize:12,color:"#2A2A3E"}}>Configuration panel coming soon</div>
        </div>}
      </div>

      {intModal&&<IntegrationModal intId={intModal.id} currentConfig={intModal.int?.config} isConnected={!!intModal.int?.connected} onClose={()=>setIntModal(null)} onSave={()=>{ api.get("/integrations").then(d=>setIntegrations(d.integrations||{})); setIntModal(null); }}/>}
      {showInvite&&<InviteModal onClose={()=>setShowInvite(false)} onInvited={()=>api.get("/team").then(setTeam)}/>}
    </div>
  );
}

// ─── Main App ──────────────────────────────────────────────────────────────────
function MainApp({ user: initUser, orgs: initOrgs, token, onLogout }) {
  const [user, setUser] = useState(initUser);
  const [orgs, setOrgs] = useState(initOrgs);
  const [currentOrg, setCurrentOrg] = useState(initOrgs.find(o=>o.id===initUser.currentOrgId)||initOrgs[0]);
  const [navCollapsed, setNavCollapsed] = useState(false);
  const [activeNav, setActiveNav] = useState("inbox");
  const [view, setView] = useState("inbox");
  const [tickets, setTickets] = useState([]);
  const [agents, setAgents] = useState([]);
  const [loading, setLoading] = useState(true);
  const [activeTicketId, setActiveTicketId] = useState(null);
  const [search, setSearch] = useState("");
  const [filterP, setFilterP] = useState("all");
  const [filterC, setFilterC] = useState("all");
  const [filterS, setFilterS] = useState("all");
  const [showFilters, setShowFilters] = useState(false);
  const [showNewTicket, setShowNewTicket] = useState(false);
  const [showOrgSwitcher, setShowOrgSwitcher] = useState(false);
  const api = useApi();
  const toast = useToast();

  const loadTickets = useCallback(async () => {
    try { const d = await api.get("/tickets"); setTickets(d.tickets||[]); }
    catch(e) { toast(e.message,"error"); }
    setLoading(false);
  }, []);

  useEffect(()=>{
    loadTickets();
    api.get("/team").then(d=>setAgents(d.members||[])).catch(()=>{});
    const interval = setInterval(loadTickets, 30000);
    return ()=>clearInterval(interval);
  },[loadTickets]);

  async function switchOrg(orgId) {
    try { const d = await api.post("/orgs/switch",{orgId}); setUser(d.user); setCurrentOrg(d.org); loadTickets(); setShowOrgSwitcher(false); toast(`Switched to ${d.org.name}`,"success"); }
    catch(e) { toast(e.message,"error"); }
  }

  const filtered = tickets.filter(t => {
    if (search && !t.title.toLowerCase().includes(search.toLowerCase()) && !t.id.toLowerCase().includes(search.toLowerCase()) && !t.customer.toLowerCase().includes(search.toLowerCase())) return false;
    if (filterP!=="all"&&t.priority!==filterP) return false;
    if (filterC!=="all"&&t.channel!==filterC) return false;
    if (filterS!=="all"&&t.status!==filterS) return false;
    return true;
  });

  const openCount   = tickets.filter(t=>t.status==="open").length;
  const unread      = tickets.filter(t=>t.unread).length;
  const critical    = tickets.filter(t=>t.priority==="critical"&&!["resolved","closed"].includes(t.status)).length;

  const NAV = [
    {id:"inbox",    label:"Inbox",     icon:"⬇", badge:unread},
    {id:"myqueue",  label:"My Queue",  icon:"◈", badge:tickets.filter(t=>t.assigneeId===user.id&&t.status==="open").length||0},
    {id:"reports",  label:"Reports",   icon:"◎"},
    {id:"customers",label:"Customers", icon:"◯"},
    {id:"settings", label:"Settings",  icon:"⚙"},
  ];

  const VIEW_TABS = [{id:"inbox",label:"Inbox",icon:"⬇"},{id:"kanban",label:"Kanban",icon:"⊞"},{id:"list",label:"List",icon:"☰"},{id:"cards",label:"Cards",icon:"⊡"}];

  return (
    <div style={{fontFamily:"'DM Sans',-apple-system,sans-serif",background:"#07070F",color:"#AEAEB2",height:"100vh",display:"flex",flexDirection:"column",overflow:"hidden"}}>
      <div style={{display:"flex",flex:1,overflow:"hidden"}}>

        {/* Sidebar */}
        <div style={{width:navCollapsed?54:208,background:"#0A0A18",borderRight:"1px solid #12121E",display:"flex",flexDirection:"column",flexShrink:0,transition:"width 0.22s cubic-bezier(0.4,0,0.2,1)",overflow:"hidden"}}>
          {/* Logo + Org + Collapse */}
          <div style={{padding:"12px 10px",borderBottom:"1px solid #12121E",display:"flex",alignItems:"center",gap:9,minHeight:54}}>
            <div style={{width:30,height:30,borderRadius:8,background:"linear-gradient(135deg,#4F8EF7,#A855F7)",display:"flex",alignItems:"center",justifyContent:"center",fontSize:15,fontWeight:900,color:"#fff",flexShrink:0}}>S</div>
            {!navCollapsed&&<div style={{flex:1,minWidth:0,cursor:"pointer"}} onClick={()=>setShowOrgSwitcher(s=>!s)}>
              <div style={{fontSize:12,fontWeight:800,color:"#F2F2F7",overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>{currentOrg?.name||"SupportOS"}</div>
              <div style={{fontSize:9,color:"#636366",letterSpacing:"0.5px",display:"flex",alignItems:"center",gap:3}}><span style={{color:PLANS[currentOrg?.plan||"free"]?.badge||"#636366",fontWeight:700}}>{(currentOrg?.plan||"free").toUpperCase()}</span> · click to switch ▾</div>
            </div>}
            <button onClick={()=>setNavCollapsed(c=>!c)} style={{background:"none",border:"none",color:"#636366",cursor:"pointer",fontSize:11,padding:3,flexShrink:0,marginLeft:"auto",transition:"color 0.15s"}} onMouseEnter={e=>e.currentTarget.style.color="#F2F2F7"} onMouseLeave={e=>e.currentTarget.style.color="#636366"}>{navCollapsed?"⇥":"⇤"}</button>
          </div>

          {/* Org Switcher Dropdown */}
          {!navCollapsed&&showOrgSwitcher&&(
            <div style={{background:"#0D0D1A",borderBottom:"1px solid #1E1E2E"}}>
              {orgs.map(o=>(
                <div key={o.id} onClick={()=>switchOrg(o.id)} style={{display:"flex",alignItems:"center",gap:8,padding:"8px 12px",cursor:"pointer",background:o.id===currentOrg?.id?"#1A1A2E":"transparent",transition:"background 0.1s"}}
                  onMouseEnter={e=>e.currentTarget.style.background="#1A1A2E"} onMouseLeave={e=>e.currentTarget.style.background=o.id===currentOrg?.id?"#1A1A2E":"transparent"}>
                  <div style={{width:22,height:22,borderRadius:5,background:"linear-gradient(135deg,#4F8EF7,#A855F7)",display:"flex",alignItems:"center",justifyContent:"center",fontSize:10,fontWeight:900,color:"#fff"}}>{o.name[0]}</div>
                  <div style={{flex:1,minWidth:0}}>
                    <div style={{fontSize:12,color:"#F2F2F7",fontWeight:600,overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>{o.name}</div>
                    <div style={{fontSize:9,color:"#636366"}}>{o.plan.toUpperCase()}</div>
                  </div>
                  {o.id===currentOrg?.id&&<span style={{color:"#4F8EF7",fontSize:12}}>✓</span>}
                </div>
              ))}
              <div onClick={()=>{toast("Create org — coming soon","info");setShowOrgSwitcher(false);}} style={{padding:"8px 12px",cursor:"pointer",fontSize:11,color:"#4F8EF7",borderTop:"1px solid #1E1E2E"}} onMouseEnter={e=>e.currentTarget.style.background="#1A1A2E"} onMouseLeave={e=>e.currentTarget.style.background="transparent"}>+ Create new workspace</div>
            </div>
          )}

          {/* Stats */}
          {!navCollapsed&&<div style={{padding:"8px",display:"grid",gridTemplateColumns:"1fr 1fr 1fr",gap:4,borderBottom:"1px solid #12121E"}}>
            {[{l:"Open",v:openCount,c:"#4F8EF7"},{l:"Unread",v:unread,c:"#A855F7"},{l:"Crit",v:critical,c:"#FF3B30"}].map(s=>(
              <div key={s.l} style={{background:`${s.c}10`,border:`1px solid ${s.c}25`,borderRadius:6,padding:"5px 3px",textAlign:"center"}}>
                <div style={{fontSize:14,fontWeight:800,color:s.c,lineHeight:1,fontFamily:"'DM Mono',monospace"}}>{s.v}</div>
                <div style={{fontSize:9,color:s.c,opacity:0.6,marginTop:1}}>{s.l}</div>
              </div>
            ))}
          </div>}

          {/* Nav */}
          <nav style={{flex:1,overflow:"auto",padding:"6px 0"}}>
            {NAV.map(item=>(
              <button key={item.id} onClick={()=>{setActiveNav(item.id);if(item.id!=="settings")setView(item.id==="myqueue"?"inbox":item.id);}} title={navCollapsed?item.label:undefined}
                style={{width:"100%",display:"flex",alignItems:"center",gap:9,padding:navCollapsed?"10px 0":"8px 12px",justifyContent:navCollapsed?"center":"flex-start",background:activeNav===item.id?"#1A1A2E":"none",border:"none",borderRight:activeNav===item.id?"2px solid #4F8EF7":"2px solid transparent",color:activeNav===item.id?"#F2F2F7":"#636366",cursor:"pointer",fontSize:13,fontWeight:activeNav===item.id?600:400,transition:"all 0.15s",textAlign:"left",position:"relative",fontFamily:"inherit"}}>
                <span style={{fontSize:14,flexShrink:0}}>{item.icon}</span>
                {!navCollapsed&&<span style={{flex:1,whiteSpace:"nowrap"}}>{item.label}</span>}
                {!navCollapsed&&item.badge>0&&<span style={{background:activeNav===item.id?"#4F8EF7":"#1E1E2E",color:activeNav===item.id?"#fff":"#8E8E93",fontSize:10,fontWeight:700,padding:"1px 6px",borderRadius:10,fontFamily:"'DM Mono',monospace"}}>{item.badge}</span>}
                {navCollapsed&&item.badge>0&&<span style={{position:"absolute",top:5,right:5,width:7,height:7,borderRadius:"50%",background:"#4F8EF7",boxShadow:"0 0 5px #4F8EF7"}}/>}
              </button>
            ))}
          </nav>

          {/* Team online */}
          {!navCollapsed&&<div style={{padding:"8px 10px",borderTop:"1px solid #12121E"}}>
            <div style={{fontSize:9,color:"#636366",fontWeight:700,letterSpacing:"0.8px",textTransform:"uppercase",marginBottom:6}}>Team</div>
            {agents.slice(0,4).map(a=>(
              <div key={a.id} style={{display:"flex",alignItems:"center",gap:6,marginBottom:4}}>
                <Avatar agent={a} size={17}/>
                <span style={{fontSize:11,color:"#AEAEB2",flex:1,overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>{a.name.split(" ")[0]}</span>
                <span style={{fontSize:10,color:"#636366",fontFamily:"'DM Mono',monospace"}}>{a.tickets||0}</span>
              </div>
            ))}
          </div>}

          {/* Me */}
          <div style={{padding:"8px 10px",borderTop:"1px solid #12121E",display:"flex",alignItems:"center",gap:8,justifyContent:navCollapsed?"center":"flex-start"}}>
            <Avatar agent={user} size={24}/>
            {!navCollapsed&&<div style={{flex:1,minWidth:0}}>
              <div style={{fontSize:11,color:"#F2F2F7",fontWeight:600,overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>{user.name}</div>
              <div style={{fontSize:10,color:"#34C759"}}>● {user.status||"online"}</div>
            </div>}
            {!navCollapsed&&<button onClick={onLogout} style={{background:"none",border:"none",color:"#636366",cursor:"pointer",fontSize:11}} title="Sign out" onMouseEnter={e=>e.currentTarget.style.color="#FF3B30"} onMouseLeave={e=>e.currentTarget.style.color="#636366"}>↩</button>}
          </div>
        </div>

        {/* Main */}
        <div style={{flex:1,display:"flex",overflow:"hidden",flexDirection:"column"}}>
          {activeNav==="settings"&&<SettingsPage user={user} org={currentOrg} onOrgUpdate={setCurrentOrg}/>}
          {activeNav==="reports"&&<ReportsPage/>}
          {activeNav==="customers"&&<CustomersPage/>}

          {!["settings","reports","customers"].includes(activeNav)&&<>
            {/* Top Bar */}
            <div style={{padding:"9px 16px",borderBottom:"1px solid #12121E",display:"flex",alignItems:"center",gap:9,flexShrink:0,background:"#0A0A18"}}>
              <div style={{display:"flex",background:"#0D0D1A",borderRadius:8,padding:3,border:"1px solid #1E1E2E",gap:2}}>
                {VIEW_TABS.map(t=><button key={t.id} onClick={()=>setView(t.id)} style={{padding:"4px 10px",borderRadius:6,background:view===t.id?"#1A1A2E":"none",border:`1px solid ${view===t.id?"#2D2D3F":"transparent"}`,color:view===t.id?"#F2F2F7":"#636366",cursor:"pointer",fontSize:11,fontWeight:view===t.id?600:400,display:"flex",alignItems:"center",gap:4,transition:"all 0.15s",whiteSpace:"nowrap",fontFamily:"inherit"}}>
                  <span>{t.icon}</span>{t.label}
                </button>)}
              </div>
              <div style={{flex:1,position:"relative",maxWidth:340}}>
                <span style={{position:"absolute",left:9,top:"50%",transform:"translateY(-50%)",color:"#636366",fontSize:13}}>⌕</span>
                <input value={search} onChange={e=>setSearch(e.target.value)} placeholder="Search tickets, customers, IDs…" style={{width:"100%",background:"#0D0D1A",border:"1px solid #1E1E2E",borderRadius:8,padding:"6px 12px 6px 28px",color:"#AEAEB2",fontSize:12,outline:"none",fontFamily:"inherit"}} onFocus={e=>e.target.style.borderColor="#4F8EF7"} onBlur={e=>e.target.style.borderColor="#1E1E2E"}/>
              </div>
              <button onClick={()=>setShowFilters(f=>!f)} style={{padding:"6px 11px",background:showFilters?"#4F8EF720":"#0D0D1A",border:`1px solid ${showFilters?"#4F8EF7":"#1E1E2E"}`,borderRadius:8,color:showFilters?"#4F8EF7":"#636366",cursor:"pointer",fontSize:11,fontWeight:600,transition:"all 0.15s",fontFamily:"inherit"}}>⚙ Filter</button>
              <button onClick={loadTickets} style={{padding:"6px 10px",background:"#0D0D1A",border:"1px solid #1E1E2E",borderRadius:8,color:"#636366",cursor:"pointer",fontSize:13,fontFamily:"inherit"}} title="Refresh">↻</button>
              <Btn variant="primary" onClick={()=>setShowNewTicket(true)} style={{whiteSpace:"nowrap"}}>+ New Ticket</Btn>
            </div>
            {showFilters&&<div style={{padding:"7px 16px",borderBottom:"1px solid #12121E",display:"flex",gap:10,alignItems:"center",background:"#080813"}}>
              {[{l:"Priority",v:filterP,set:setFilterP,opts:["all",...Object.keys(PRIORITIES)]},{l:"Channel",v:filterC,set:setFilterC,opts:["all",...Object.keys(CHANNELS)]},{l:"Status",v:filterS,set:setFilterS,opts:["all",...Object.keys(STATUSES)]}].map(f=>(
                <div key={f.l} style={{display:"flex",alignItems:"center",gap:5}}>
                  <span style={{fontSize:9,color:"#636366",fontWeight:700,letterSpacing:"0.5px"}}>{f.l.toUpperCase()}</span>
                  <select value={f.v} onChange={e=>f.set(e.target.value)} style={{background:"#0D0D1A",border:"1px solid #2D2D3F",borderRadius:6,color:"#AEAEB2",fontSize:11,padding:"4px 7px",outline:"none",cursor:"pointer",fontFamily:"inherit"}}>
                    {f.opts.map(o=><option key={o} value={o}>{o.charAt(0).toUpperCase()+o.slice(1)}</option>)}
                  </select>
                </div>
              ))}
              <button onClick={()=>{setFilterP("all");setFilterC("all");setFilterS("all");setSearch("");}} style={{padding:"3px 8px",background:"none",border:"1px solid #2D2D3F",borderRadius:5,color:"#636366",cursor:"pointer",fontSize:10,fontFamily:"inherit"}}>Clear</button>
              <span style={{marginLeft:"auto",fontSize:11,color:"#636366"}}>{filtered.length} tickets</span>
            </div>}

            {/* Content */}
            <div style={{flex:1,overflow:"auto"}}>
              {loading&&<div style={{display:"flex",alignItems:"center",justifyContent:"center",height:"100%",color:"#636366",fontSize:13}}>Loading tickets…</div>}
              {!loading&&(view==="inbox"||view==="myqueue")&&<>{filtered.length===0&&<div style={{textAlign:"center",padding:"60px 0",color:"#636366",fontSize:13}}>No tickets found</div>}{filtered.map(t=><TicketRow key={t.id} ticket={t} onClick={()=>setActiveTicketId(t.id)}/>)}</>}
              {!loading&&view==="kanban"&&<KanbanBoard tickets={filtered} onOpen={setActiveTicketId}/>}
              {!loading&&view==="list"&&<div>
                <div style={{display:"grid",gridTemplateColumns:"80px 1fr 88px 88px 78px 108px 76px 36px",gap:8,padding:"8px 18px",borderBottom:"1px solid #1E1E2E",fontSize:9,color:"#636366",fontWeight:700,letterSpacing:"1px",textTransform:"uppercase"}}>
                  <span>ID</span><span>Title</span><span>Channel</span><span>Priority</span><span>Status</span><span>Customer</span><span>SLA</span><span>Msgs</span>
                </div>
                {filtered.map(t=><div key={t.id} onClick={()=>setActiveTicketId(t.id)} style={{display:"grid",gridTemplateColumns:"80px 1fr 88px 88px 78px 108px 76px 36px",gap:8,padding:"9px 18px",borderBottom:"1px solid #0D0D1A",cursor:"pointer",alignItems:"center",transition:"background 0.1s"}} onMouseEnter={e=>e.currentTarget.style.background="#0F0F1F"} onMouseLeave={e=>e.currentTarget.style.background="transparent"}>
                  <span style={{fontSize:10,color:"#636366",fontFamily:"'DM Mono',monospace"}}>{t.id}</span>
                  <span style={{fontSize:12.5,color:"#AEAEB2",fontWeight:t.unread?700:400,overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>{t.title}</span>
                  <ChannelBadge ch={t.channel}/><PriorityDot p={t.priority}/><StatusBadge s={t.status}/>
                  <span style={{fontSize:11,color:"#636366",overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>{t.customer}</span>
                  <SlaBar pct={t.slaPct||0} sla={t.sla||480}/>
                  <span style={{fontSize:11,color:"#636366"}}>💬 {t.messageCount||0}</span>
                </div>)}
              </div>}
              {!loading&&view==="cards"&&<div style={{display:"grid",gridTemplateColumns:"repeat(auto-fill,minmax(270px,1fr))",gap:12,padding:18}}>
                {filtered.map(t=><div key={t.id} onClick={()=>setActiveTicketId(t.id)} style={{background:"#0D0D1A",border:"1px solid #1E1E2E",borderRadius:10,padding:14,cursor:"pointer",transition:"all 0.15s",position:"relative",overflow:"hidden"}}
                  onMouseEnter={e=>{e.currentTarget.style.borderColor="#3A3A4E";e.currentTarget.style.transform="translateY(-2px)";e.currentTarget.style.boxShadow="0 8px 30px #00000060";}} onMouseLeave={e=>{e.currentTarget.style.borderColor="#1E1E2E";e.currentTarget.style.transform="translateY(0)";e.currentTarget.style.boxShadow="none";}}>
                  <div style={{position:"absolute",top:0,left:0,right:0,height:2,background:`linear-gradient(90deg,${PRIORITIES[t.priority]?.color||"#4F8EF7"},transparent)`}}/>
                  <div style={{display:"flex",justifyContent:"space-between",marginBottom:8}}><span style={{fontSize:10,color:"#636366",fontFamily:"'DM Mono',monospace"}}>{t.id}</span><ChannelBadge ch={t.channel}/></div>
                  <div style={{fontSize:13,fontWeight:600,color:"#E5E5EA",marginBottom:8,lineHeight:1.4}}>{t.title}</div>
                  <div style={{display:"flex",gap:5,marginBottom:7,flexWrap:"wrap"}}><PriorityDot p={t.priority}/><StatusBadge s={t.status}/></div>
                  <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",paddingTop:8,borderTop:"1px solid #1E1E2E"}}>
                    <div style={{display:"flex",alignItems:"center",gap:5}}><Avatar agent={t.assignee} size={18}/><span style={{fontSize:10,color:"#636366"}}>{t.customer}</span></div>
                    <SlaBar pct={t.slaPct||0} sla={t.sla||480}/>
                  </div>
                </div>)}
              </div>}
            </div>
          </>}
        </div>
      </div>

      {/* Overlays */}
      {activeTicketId&&<FloatingTicketPane ticketId={activeTicketId} agents={agents} onClose={()=>setActiveTicketId(null)} onUpdated={updated=>setTickets(ts=>ts.map(t=>t.id===updated.id?{...t,...updated}:t))}/>}
      {showNewTicket&&<NewTicketModal agents={agents} onClose={()=>setShowNewTicket(false)} onCreated={t=>{setTickets(ts=>[t,...ts]);setActiveTicketId(t.id);}}/>}
    </div>
  );
}

// ─── Root ─────────────────────────────────────────────────────────────────────
export default function App() {
  const [authState, setAuthState] = useState(() => {
    const t=sessionStorage.getItem("sos_token"), u=sessionStorage.getItem("sos_user"), o=sessionStorage.getItem("sos_orgs");
    if(t&&u&&o) return {token:t,user:JSON.parse(u),orgs:JSON.parse(o)};
    return null;
  });

  function handleAuth(token, user, orgs) {
    sessionStorage.setItem("sos_token",token);
    sessionStorage.setItem("sos_user",JSON.stringify(user));
    sessionStorage.setItem("sos_orgs",JSON.stringify(orgs));
    setAuthState({token,user,orgs});
  }
  function handleLogout() {
    sessionStorage.clear(); setAuthState(null);
  }

  return (
    <AuthCtx.Provider value={authState||{token:null}}>
      <ToastProvider>
        <style>{`
          @import url('https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700;800&family=DM+Mono:wght@400;500;700&display=swap');
          *{box-sizing:border-box;margin:0;padding:0;scrollbar-width:thin;scrollbar-color:#2D2D3F #0A0A18}
          ::-webkit-scrollbar{width:4px;height:4px}
          ::-webkit-scrollbar-track{background:#0A0A18}
          ::-webkit-scrollbar-thumb{background:#2D2D3F;border-radius:2px}
          input::placeholder,textarea::placeholder{color:#3A3A4E}
          button{font-family:inherit}
          @keyframes fdIn{from{opacity:0}to{opacity:1}}
          @keyframes slIn{from{transform:translateX(100%)}to{transform:translateX(0)}}
          @keyframes slInR{from{opacity:0;transform:translateX(20px)}to{opacity:1;transform:translateX(0)}}
          @keyframes slInUp{from{opacity:0;transform:translateY(16px)}to{opacity:1;transform:translateY(0)}}
        `}</style>
        {!authState
          ? <LoginScreen onAuth={handleAuth}/>
          : <MainApp user={authState.user} orgs={authState.orgs} token={authState.token} onLogout={handleLogout}/>
        }
      </ToastProvider>
    </AuthCtx.Provider>
  );
}
